# -*- coding: utf-8 -*-
import os, re, math, zipfile
from collections import Counter, defaultdict
import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import matplotlib as mpl
from networkx.algorithms.community import greedy_modularity_communities

EXCEL_PATH = r"/mnt/data/조선시대 계회시 목록.xlsx"
OUTDIR = r"/mnt/data/1gram_의미연결망_readable"
os.makedirs(OUTDIR, exist_ok=True)
FONT_PATH = r"/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
FP = fm.FontProperties(fname=FONT_PATH)
mpl.rcParams["axes.unicode_minus"] = False

df = pd.read_excel(EXCEL_PATH, sheet_name=0)
stopwords = set(list("之其而以於于也矣焉兮乎哉者所乃與及且為曰云則非無有不復亦又更可何我吾爾汝彼此是斯相諸各皆每"))
numerals = set(list("一二三四五六七八九十百千萬兩雙第"))
stopwords = stopwords - numerals
aliases = {'사헌부': ['驄馬', '憲府', '栢府', '相臺', '烏臺', '御史臺', '監察司', '大관', '臺官'], '사간원': ['薇院', '諫院', '臺諫', '대간'], '승정원': ['銀臺', '政院', '喉院', '代言司', '대언사'], '의금부': ['金吾', '禁府', '王府', '詔獄', '金部']}
HAN_RE = re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]')
alias_chars=set()
for lst in aliases.values():
    for w in lst:
        alias_chars.update(HAN_RE.findall(str(w)))
stopwords = stopwords - alias_chars

def tokenize_1gram(text):
    if not isinstance(text, str):
        return []
    chars = HAN_RE.findall(text)
    return [c for c in chars if c not in stopwords]

df["tokens"] = df["원문"].apply(tokenize_1gram)
df["is_private"] = df["유형"].astype(str).str.contains("0", na=False)
df["group_pc"] = np.where(df["is_private"], "개인", "관청")

def cooc_counts(docs, window=5):
    node = Counter(); pair = Counter()
    for toks in docs:
        node.update(toks)
        L=len(toks)
        for i in range(L):
            a=toks[i]
            for b in toks[i+1:i+window]:
                if a==b: continue
                x,y=(a,b) if a<b else (b,a)
                pair[(x,y)]+=1
    return node, pair

def edge_npmi(node, pair):
    tot_node=sum(node.values()); tot_pair=sum(pair.values())
    out={}
    if tot_node==0 or tot_pair==0: return out
    for (a,b),c in pair.items():
        pa=node[a]/tot_node; pb=node[b]/tot_node; pab=c/tot_pair
        pmi=math.log((pab/(pa*pb))+1e-12)
        out[(a,b)] = pmi/(-math.log(pab+1e-12))
    return out

def build_graph(node, pair, top_nodes=70, min_node=8, min_pair=3, top_edges=260):
    nodes=[w for w,c in node.most_common() if c>=min_node][:top_nodes]
    nodes_set=set(nodes)
    npmi=edge_npmi(node,pair)
    edges=[]
    for (a,b),c in pair.items():
        if c<min_pair or a not in nodes_set or b not in nodes_set: continue
        w=npmi.get((a,b),0.0)
        score=w*math.log(c+1)
        edges.append((a,b,c,w,score))
    edges=sorted(edges, key=lambda x:x[4], reverse=True)[:top_edges]
    G=nx.Graph()
    for n in nodes: G.add_node(n, freq=node[n])
    for a,b,c,w,score in edges: G.add_edge(a,b, weight=w, count=c, score=score)
    return G

def backbone_topm_per_node(G, m=2, min_weight=None):
    keep=set()
    for n in G.nodes():
        nbrs=[]
        for v,data in G[n].items():
            sc=data.get('score',0.0); w=data.get('weight',0.0)
            if min_weight is not None and w<min_weight: continue
            nbrs.append((v,sc))
        nbrs.sort(key=lambda x:x[1], reverse=True)
        for v,_ in nbrs[:m]:
            a,b=(n,v) if n<v else (v,n)
            keep.add((a,b))
    H=nx.Graph()
    for u,v in keep:
        if G.has_edge(u,v):
            H.add_node(u, **G.nodes[u]); H.add_node(v, **G.nodes[v])
            H.add_edge(u,v, **G.edges[u,v])
    return H

def assign_communities(G):
    if G.number_of_edges()==0:
        return {n:0 for n in G.nodes()}, [set(G.nodes())]
    comms=list(greedy_modularity_communities(G, weight='weight'))
    node2c={}
    for i,cset in enumerate(comms):
        for n in cset: node2c[n]=i
    for n in G.nodes(): node2c.setdefault(n,0)
    return node2c, comms

def weighted_degree(G):
    wdeg=defaultdict(float)
    for u,v,data in G.edges(data=True):
        w=data.get('weight',0.0)
        wdeg[u]+=w; wdeg[v]+=w
    return wdeg

def draw_readable_network(G, title, outpath, seed=7, label_top=24):
    plt.figure(figsize=(12.5,10))
    if G.number_of_nodes()==0 or G.number_of_edges()==0:
        plt.title(title, fontproperties=FP); plt.axis('off')
        plt.savefig(outpath, dpi=320, bbox_inches='tight'); plt.close(); return
    node2c, comms = assign_communities(G)
    pos = nx.spring_layout(G, seed=seed, k=0.9, weight='weight', iterations=200)
    freqs=np.array([G.nodes[n].get('freq',1) for n in G.nodes()])
    node_sizes=120+160*np.log1p(freqs)
    cmap=plt.get_cmap('Pastel1')
    node_colors=[cmap(node2c[n] % cmap.N) for n in G.nodes()]
    edges=list(G.edges())
    scores=np.array([G.edges[e].get('score',0.0) for e in edges])
    widths=0.4+3.2*(scores-scores.min())/(scores.max()-scores.min()+1e-9) if len(scores)>0 else []
    nx.draw_networkx_edges(G, pos, width=widths, edge_color='#9aa0a6', alpha=0.22)
    nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, edgecolors='#6b7280', linewidths=0.6, alpha=0.90)
    wdeg=weighted_degree(G)
    top_nodes=[n for n,_ in sorted(wdeg.items(), key=lambda x:x[1], reverse=True)[:label_top]]
    for n in top_nodes:
        x,y=pos[n]
        plt.text(x,y,n,fontproperties=FP,fontsize=12,ha='center',va='center')
    plt.title(title, fontproperties=FP); plt.axis('off')
    plt.text(0.01,0.01,f'노드색=커뮤니티(모듈성), 라벨=중심 노드 Top{label_top}', transform=plt.gca().transAxes, fontproperties=FP, fontsize=10, alpha=0.9)
    plt.savefig(outpath, dpi=340, bbox_inches='tight'); plt.close()

def top_edges_bar(G, title, outpath, top_n=25):
    rows=[]
    for u,v,data in G.edges(data=True):
        rows.append((u,v,data.get('score',0.0), data.get('weight',0.0), data.get('count',0)))
    rows.sort(key=lambda x:x[2], reverse=True); rows=rows[:top_n]
    plt.figure(figsize=(11,7.2))
    if not rows:
        plt.title(title, fontproperties=FP); plt.axis('off')
        plt.savefig(outpath, dpi=300, bbox_inches='tight'); plt.close(); return
    labels=[f'{u}-{v}' for u,v,_,_,_ in rows][::-1]
    scores=[s for _,_,s,_,_ in rows][::-1]
    wvals=[w for _,_,_,w,_ in rows][::-1]
    y=np.arange(len(labels))
    plt.barh(y, scores)
    plt.yticks(y, labels, fontproperties=FP, fontsize=11)
    plt.xlabel('score = NPMI × log(count+1)', fontproperties=FP)
    plt.title(title, fontproperties=FP)
    for i,(s,w) in enumerate(zip(scores,wvals)):
        plt.text(s, i, f' NPMI={w:.3f}', va='center', fontproperties=FP, fontsize=10)
    plt.tight_layout(); plt.savefig(outpath, dpi=320, bbox_inches='tight'); plt.close()

def community_summary(G, comms, out_csv):
    wdeg=weighted_degree(G)
    rows=[]
    for cid,cset in enumerate(comms):
        nodes=list(cset)
        nodes_sorted=sorted(nodes, key=lambda n:wdeg.get(n,0.0), reverse=True)
        for rank,n in enumerate(nodes_sorted[:12], start=1):
            rows.append([cid,rank,n,float(wdeg.get(n,0.0)), int(G.nodes[n].get('freq',0))])
    pd.DataFrame(rows, columns=['community','rank','node','weighted_degree','freq']).to_csv(out_csv, index=False, encoding='utf-8-sig')

docs_pr=df.loc[df.group_pc=='개인','tokens'].tolist()
docs_of=df.loc[df.group_pc=='관청','tokens'].tolist()
node_pr,pair_pr=cooc_counts(docs_pr, window=5)
node_of,pair_of=cooc_counts(docs_of, window=5)
G_pr=build_graph(node_pr,pair_pr, top_nodes=70, min_node=8, min_pair=3, top_edges=260)
G_of=build_graph(node_of,pair_of, top_nodes=70, min_node=12, min_pair=5, top_edges=260)
H_pr=backbone_topm_per_node(G_pr, m=2, min_weight=0.08)
H_of=backbone_topm_per_node(G_of, m=2, min_weight=0.08)
if H_pr.number_of_edges()<35: H_pr=backbone_topm_per_node(G_pr, m=3, min_weight=0.05)
if H_of.number_of_edges()<35: H_of=backbone_topm_per_node(G_of, m=3, min_weight=0.05)
draw_readable_network(H_pr, '개인 1-gram 의미연결망(가독성 개선)', os.path.join(OUTDIR,'network_private_readable_pastel.png'))
draw_readable_network(H_of, '관청 1-gram 의미연결망(가독성 개선)', os.path.join(OUTDIR,'network_official_readable_pastel.png'))
top_edges_bar(H_pr, '개인: backbone 네트워크 상위 결합 Top25', os.path.join(OUTDIR,'private_top_edges_bar.png'))
top_edges_bar(H_of, '관청: backbone 네트워크 상위 결합 Top25', os.path.join(OUTDIR,'official_top_edges_bar.png'))
_,comms_pr=assign_communities(H_pr)
_,comms_of=assign_communities(H_of)
community_summary(H_pr, comms_pr, os.path.join(OUTDIR,'private_community_summary.csv'))
community_summary(H_of, comms_of, os.path.join(OUTDIR,'official_community_summary.csv'))
print('DONE', OUTDIR)
