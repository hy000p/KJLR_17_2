# -*- coding: utf-8 -*-
"""
조선시대 계회시(엑셀 1번 시트) 기반: 숫자-문맥 고도화 분석
(A) 숫자 중심 공기어(co-word) 프로파일
(1) 기관-전용 연속숫자표현(signature) 자동 추출/랭킹(log-odds z)
(2) 숫자+표지어 노드의 "숫자-담론 네트워크"(PMI/빈도) + 차등 네트워크(log-odds z)
- 모든 결과: PNG(그래프), CSV(테이블) 저장
"""

import os, re, math
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, findSystemFonts
import networkx as nx

# =========================
# 0) 경로 설정
# =========================
EXCEL_PATH = r"/mnt/data/조선시대 계회시 목록.xlsx"            # 필요 시 수정
OUTDIR     = r"/mnt/data/number_context_advanced_outputs"      # 필요 시 수정
os.makedirs(OUTDIR, exist_ok=True)

# =========================
# 1) 폰트 설정(한자 깨짐 방지)
# =========================
def set_cjk_font():
    candidates = [
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "/usr/share/fonts/truetype/nanum/NanumMyeongjoBold.ttf",
        "/usr/share/fonts/truetype/unfonts-core/UnBatang.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            name = FontProperties(fname=p).get_name()
            rcParams["font.family"] = name
            rcParams["axes.unicode_minus"] = False
            return p, name
    for p in findSystemFonts(fontext="ttf"):
        if ("Noto" in p) or ("Nanum" in p) or ("UnBatang" in p):
            name = FontProperties(fname=p).get_name()
            rcParams["font.family"] = name
            rcParams["axes.unicode_minus"] = False
            return p, name
    return None, None

FONT_PATH, FONT_NAME = set_cjk_font()
FONT_PROP = FontProperties(fname=FONT_PATH) if FONT_PATH else None

# =========================
# 2) 데이터 로드 및 기관 매핑
# =========================
df = pd.read_excel(EXCEL_PATH, sheet_name=0)
df["유형"] = df["유형"].fillna("").astype(str)
df["원문"] = df["원문"].fillna("").astype(str)

OFFICES = ["사헌부", "사간원", "승정원", "의금부"]

def map_group(x: str) -> str:
    s = str(x).strip()
    if "0" in s:
        return "개인"
    for o in OFFICES:
        if s.startswith(o):
            return o
    return "기타관청"

df["기관"] = df["유형"].apply(map_group)
GROUP_ORDER = ["개인", "사헌부", "사간원", "승정원", "의금부", "기타관청"]

# =========================
# 3) 전처리: 한자만 남기기
# =========================
han_re = re.compile(r"[\u3007\u3400-\u4dbf\u4e00-\u9fff\uF900-\uFAFF]")  # 〇 포함
def clean_han(text: str) -> str:
    return "".join(han_re.findall(text))

df["clean"] = df["원문"].apply(clean_han)
df["tokens"] = df["clean"].apply(list)

# =========================
# 4) 분석 설정
# =========================
NUM_TOKENS = list("一二三四五六七八九十百千萬兩雙第")
TARGET_NUMS = ["一", "三", "七", "十", "第"]
WINDOW = 10  # 숫자 중심 ±윈도우

# 기능어/수사(보수적) 제거 목록 (숫자 제외)
STOPWORDS = set(list("之其而以於于也矣焉兮乎哉者所乃與及且為曰云則非無有不復亦又更可何我吾爾汝彼此是斯相諸各皆每"))

# 표지어(네트워크 노드 후보)
RECORD_MARKERS   = set(list("年月日朔望晦旬初正元春夏秋冬晨夕夜曉午辰時更刻"))
AGE_MARKERS      = set(list("歲齡壽耆老翁春秋"))
RANK_MARKERS     = set(list("第次序班席位品等行首亞"))
QUANTITY_MARKERS = set(list("人員名客僚友杯觴盞巡章篇首聲里丈尺畝戶隊家箇"))
GATHER_MARKERS   = set(list("會契軸卷圖詩序記宴集坐"))
MARKERS = RECORD_MARKERS | AGE_MARKERS | RANK_MARKERS | QUANTITY_MARKERS | GATHER_MARKERS

num_set = set(NUM_TOKENS)

# =========================
# 5) 숫자 중심 공기어 수집
# =========================
pair_counts_by_group = defaultdict(Counter)  # (num, tok) -> cnt
tok_marg_by_group    = defaultdict(Counter)  # tok -> cnt (숫자 문맥 전체)
num_marg_by_group    = defaultdict(Counter)  # num center cnt
all_tok_marg         = Counter()

for _, row in df.iterrows():
    g = row["기관"]
    toks = row["tokens"]
    for i, ch in enumerate(toks):
        if ch in num_set:
            left = max(0, i - WINDOW)
            right = min(len(toks), i + WINDOW + 1)
            ctx = toks[left:right]

            # 중심 숫자 제외 + 기능어 제거
            ctx_tokens = [t for j, t in enumerate(ctx) if (left + j) != i and t not in STOPWORDS]

            # 공기어 분석에서는 다른 숫자(一..萬/兩/雙)는 제거하되, '第'는 표지어 성격이 있어 유지
            ctx_tokens = [t for t in ctx_tokens if (t not in num_set) or (t == "第")]

            num_marg_by_group[g][ch] += 1
            for t in ctx_tokens:
                pair_counts_by_group[g][(ch, t)] += 1
                tok_marg_by_group[g][t] += 1
                all_tok_marg[t] += 1

# =========================
# 6) 시각화/지표 유틸
# =========================
def save_heatmap(mat_df: pd.DataFrame, title: str, filename: str,
                 value_fmt="{:.1f}", cbar_label="값"):
    data = mat_df.values.astype(float)
    fig, ax = plt.subplots(figsize=(max(10, 0.45 * mat_df.shape[1] + 4), max(4, 0.35 * mat_df.shape[0] + 2)))
    im = ax.imshow(data, aspect="auto")
    ax.set_xticks(np.arange(mat_df.shape[1]))
    ax.set_xticklabels(mat_df.columns, fontsize=10, rotation=45, ha="right", fontproperties=FONT_PROP)
    ax.set_yticks(np.arange(mat_df.shape[0]))
    ax.set_yticklabels(mat_df.index, fontsize=10, fontproperties=FONT_PROP)
    ax.set_title(title, fontsize=13, fontproperties=FONT_PROP)

    vmax = np.nanmax(data) if data.size else 1.0
    for i in range(mat_df.shape[0]):
        for j in range(mat_df.shape[1]):
            v = data[i, j]
            ax.text(j, i, value_fmt.format(v),
                    ha="center", va="center", fontsize=7,
                    color="white" if v > vmax * 0.65 else "black",
                    fontproperties=FONT_PROP)
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(cbar_label, fontproperties=FONT_PROP)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=220, bbox_inches="tight")
    plt.close(fig)

def save_barh(series: pd.Series, title: str, filename: str, xlabel: str, topn: int = 15):
    s = series.head(topn)[::-1]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(range(len(s)), s.values)
    ax.set_yticks(range(len(s)))
    ax.set_yticklabels(s.index, fontsize=11, fontproperties=FONT_PROP)
    ax.set_xlabel(xlabel, fontproperties=FONT_PROP)
    ax.set_title(title, fontsize=13, fontproperties=FONT_PROP)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=220, bbox_inches="tight")
    plt.close(fig)

def log_odds_z_from_counts(counts_g: Counter, counts_r: Counter,
                           alpha_base: Counter, alpha0: float = 1.0) -> pd.Series:
    vocab = set(counts_g) | set(counts_r)
    total_base = sum(alpha_base.values()) + 1e-12
    alpha = {w: alpha0 * (alpha_base.get(w, 0) + 1e-9) / total_base for w in vocab}
    n_g = sum(counts_g.values()) + 1e-12
    n_r = sum(counts_r.values()) + 1e-12
    out = {}
    for w in vocab:
        cg = counts_g.get(w, 0.0)
        cr = counts_r.get(w, 0.0)
        a = alpha[w]
        lo_g = math.log((cg + a) / (n_g + alpha0 - (cg + a) + 1e-12))
        lo_r = math.log((cr + a) / (n_r + alpha0 - (cr + a) + 1e-12))
        delta = lo_g - lo_r
        var = 1.0 / (cg + a) + 1.0 / (cr + a)
        out[w] = delta / math.sqrt(var)
    return pd.Series(out).sort_values(ascending=False)

def pmi_from_paircounts(pair_counts: Counter):
    num_marg = Counter()
    tok_marg = Counter()
    T = 0
    for (n, t), c in pair_counts.items():
        num_marg[n] += c
        tok_marg[t] += c
        T += c
    pmi = {}
    for (n, t), c in pair_counts.items():
        p_nt = c / T
        p_n = num_marg[n] / T
        p_t = tok_marg[t] / T
        pmi[(n, t)] = math.log(p_nt / (p_n * p_t) + 1e-12)
    return pmi

def draw_labels_with_font(ax, pos, labels, fontsize=11):
    for node, (x, y) in pos.items():
        ax.text(x, y, labels[node],
                fontproperties=FONT_PROP, fontsize=fontsize,
                ha="center", va="center")

def save_bipartite_network(pair_counts: Counter, title: str, filename: str,
                           top_edges: int = 70, weight_mode="pmi"):
    if not pair_counts:
        return

    if weight_mode == "pmi":
        pmi = pmi_from_paircounts(pair_counts)
        edges_sorted = sorted(pair_counts.keys(), key=lambda e: pmi.get(e, -999), reverse=True)
        chosen = []
        for e in edges_sorted:
            if pair_counts[e] >= 2:  # 너무 희귀한 결합 제거
                chosen.append(e)
            if len(chosen) >= top_edges:
                break
        edge_list = [(e[0], e[1], pmi[e]) for e in chosen]
        vals = [w for _, _, w in edge_list]
    else:
        chosen = [e for e, _ in pair_counts.most_common(top_edges)]
        edge_list = [(e[0], e[1], pair_counts[e]) for e in chosen]
        vals = [w for _, _, w in edge_list]

    G = nx.Graph()
    for n, t, w in edge_list:
        G.add_node(n)
        G.add_node(t)
        G.add_edge(n, t, w=w)

    pos = nx.spring_layout(G, seed=42, k=0.8 / math.sqrt(max(G.number_of_nodes(), 1)))
    widths = [0.7 + (w - min(vals)) / (np.ptp(vals) + 1e-9) * 3.0 for w in vals]
    sizes = [900 if node in num_set else 350 for node in G.nodes()]
    labels = {node: node for node in G.nodes()}

    fig, ax = plt.subplots(figsize=(12, 8))
    nx.draw_networkx_edges(G, pos, width=widths, alpha=0.6, ax=ax)
    nx.draw_networkx_nodes(G, pos, node_size=sizes, ax=ax)
    draw_labels_with_font(ax, pos, labels, fontsize=11)
    ax.set_title(title, fontsize=13, fontproperties=FONT_PROP)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=220, bbox_inches="tight")
    plt.close(fig)

# =========================
# 7) (A) 숫자 문맥 공기어 결과
# =========================
topK = 25
top_tokens = [w for w, _ in all_tok_marg.most_common(topK)]

ctx_rate = pd.DataFrame(index=GROUP_ORDER, columns=top_tokens, dtype=float)
for g in GROUP_ORDER:
    total = sum(tok_marg_by_group[g].values())
    for w in top_tokens:
        ctx_rate.loc[g, w] = (tok_marg_by_group[g].get(w, 0) / total * 1000) if total > 0 else 0.0

ctx_rate.to_csv(os.path.join(OUTDIR, "table_top_context_tokens_per1kctx.csv"), encoding="utf-8-sig")
save_heatmap(ctx_rate,
             "숫자 주변 공기어(전체) 상위 25: 기관별 분포(문맥 토큰 1,000당)",
             "01_context_top25_heatmap_per1kctx.png",
             value_fmt="{:.1f}", cbar_label="문맥 1,000당")

# 특정 숫자 주변 공기어(기관별 ‘해당 숫자 100회당’ 공출현률)
for num in TARGET_NUMS:
    overall_for_num = Counter()
    for g in pair_counts_by_group:
        for (n, t), c in pair_counts_by_group[g].items():
            if n == num:
                overall_for_num[t] += c
    co_tokens = [w for w, _ in overall_for_num.most_common(15)]

    mat = pd.DataFrame(index=GROUP_ORDER, columns=co_tokens, dtype=float)
    for g in GROUP_ORDER:
        denom = num_marg_by_group[g].get(num, 0)
        for w in co_tokens:
            mat.loc[g, w] = (pair_counts_by_group[g].get((num, w), 0) / denom * 100) if denom > 0 else 0.0

    mat.to_csv(os.path.join(OUTDIR, f"table_cowords_rate_per100occ_{num}.csv"), encoding="utf-8-sig")
    save_heatmap(mat,
                 f"‘{num}’ 주변 공기어(상위 15): 기관별 공출현률(‘{num}’ 100회당)",
                 f"02_cowords_heatmap_{num}.png",
                 value_fmt="{:.1f}", cbar_label=f"‘{num}’ 100회당")

# 기관별 숫자문맥 공기어 signature (log-odds z)
overall_ctx_counts = Counter(all_tok_marg)
for g in ["개인", "사헌부", "사간원", "승정원", "의금부"]:
    cg = tok_marg_by_group[g]
    cr = overall_ctx_counts - cg
    z = log_odds_z_from_counts(cg, cr, alpha_base=overall_ctx_counts, alpha0=1.0)
    z.to_csv(os.path.join(OUTDIR, f"table_context_logodds_{g}.csv"), encoding="utf-8-sig")
    z_pos = z[(z > 0) & (z.index.map(lambda w: cg.get(w, 0) >= 5))].sort_values(ascending=False)
    save_barh(z_pos,
              f"{g}: 숫자 주변 문맥 공기어의 변별성(log-odds z, +)",
              f"03_context_logodds_{g}.png",
              xlabel="log-odds z (해당 기관 숫자문맥 vs 나머지)", topn=15)

# =========================
# 8) (1) 기관-전용 연속숫자표현(signature) 추출/랭킹 + KWIC
# =========================
num_chars = "".join(NUM_TOKENS)
seq_re = re.compile(f"[{re.escape(num_chars)}]{{2,}}")

df["num_seq_list"] = df["clean"].apply(lambda s: seq_re.findall(s))

seq_counts_by_group = defaultdict(Counter)
overall_seq = Counter()

for g, sub in df.groupby("기관"):
    c = Counter()
    for lst in sub["num_seq_list"]:
        c.update(lst)
    seq_counts_by_group[g] = c
    overall_seq.update(c)

overall_seq_counts = Counter(overall_seq)

seq_freq_table = pd.DataFrame({g: pd.Series(seq_counts_by_group[g]) for g in GROUP_ORDER}).fillna(0).astype(int)
seq_freq_table["전체"] = seq_freq_table.sum(axis=1)
seq_freq_table.sort_values("전체", ascending=False).head(200).to_csv(
    os.path.join(OUTDIR, "table_numseq_counts_top200.csv"),
    encoding="utf-8-sig"
)

for g in ["개인", "사헌부", "사간원", "승정원", "의금부"]:
    cg = seq_counts_by_group[g]
    if sum(cg.values()) == 0:
        continue
    cr = overall_seq_counts - cg
    z = log_odds_z_from_counts(cg, cr, alpha_base=overall_seq_counts, alpha0=1.0)
    z.to_csv(os.path.join(OUTDIR, f"table_numseq_logodds_{g}.csv"), encoding="utf-8-sig")
    z_pos = z[(z > 0) & (z.index.map(lambda w: cg.get(w, 0) >= 2))].sort_values(ascending=False)
    save_barh(z_pos,
              f"{g}: 기관-전용 숫자표현 후보(연속숫자, log-odds z, +)",
              f"04_numseq_signature_{g}.png",
              xlabel="log-odds z (해당 기관 vs 나머지)", topn=15)

# KWIC 샘플(각 기관: '二十四' 있으면 그것, 없으면 최빈 표현)
kwic_rows = []
for g in ["사헌부", "사간원", "승정원", "의금부", "개인"]:
    cg = seq_counts_by_group[g]
    if not cg:
        continue
    target_seq = "二十四" if "二十四" in cg else cg.most_common(1)[0][0]
    cnt = 0
    for _, row in df[df["기관"] == g].iterrows():
        s = row["clean"]
        if target_seq in s:
            pos = s.find(target_seq)
            left = max(0, pos - 20)
            right = min(len(s), pos + len(target_seq) + 20)
            snippet = s[left:pos] + "[" + target_seq + "]" + s[pos + len(target_seq):right]
            kwic_rows.append((g, target_seq, row.get("제목", ""), snippet))
            cnt += 1
            if cnt >= 15:
                break

pd.DataFrame(kwic_rows, columns=["기관", "표현", "제목", "KWIC"]).to_csv(
    os.path.join(OUTDIR, "table_kwic_numseq_samples.csv"),
    index=False, encoding="utf-8-sig"
)

# =========================
# 9) (2) 숫자-담론 네트워크(숫자 + 표지어) + 차등 네트워크
# =========================
marker_pair_by_group = defaultdict(Counter)
overall_marker_pairs = Counter()

for g in pair_counts_by_group:
    for (num, tok), c in pair_counts_by_group[g].items():
        if tok in MARKERS:
            marker_pair_by_group[g][(num, tok)] += c
            overall_marker_pairs[(num, tok)] += c

# PMI/빈도 네트워크
for g in ["개인", "사헌부", "사간원", "승정원", "의금부"]:
    pc = marker_pair_by_group.get(g, Counter())
    save_bipartite_network(pc,
                           f"{g}: 숫자-담론 네트워크(숫자 ↔ 표지어, PMI 상위)",
                           f"05_num_marker_network_pmi_{g}.png",
                           top_edges=70, weight_mode="pmi")
    save_bipartite_network(pc,
                           f"{g}: 숫자-담론 네트워크(숫자 ↔ 표지어, 빈도 상위)",
                           f"05_num_marker_network_count_{g}.png",
                           top_edges=70, weight_mode="count")

# 차등 네트워크(log-odds z 상위 결합)
def save_diff_network(top_edges, title, filename):
    if not top_edges:
        return
    G = nx.Graph()
    for (n, t), z, cnt in top_edges:
        G.add_node(n); G.add_node(t)
        G.add_edge(n, t, z=z, cnt=cnt)

    pos = nx.spring_layout(G, seed=7, k=0.8 / math.sqrt(max(G.number_of_nodes(), 1)))
    zvals = [G.edges[e]["z"] for e in G.edges()]
    widths = [0.8 + (z - min(zvals)) / (np.ptp(zvals) + 1e-9) * 3.2 for z in zvals]
    sizes = [900 if node in num_set else 350 for node in G.nodes()]
    labels = {node: node for node in G.nodes()}

    fig, ax = plt.subplots(figsize=(12, 8))
    nx.draw_networkx_edges(G, pos, width=widths, alpha=0.65, ax=ax)
    nx.draw_networkx_nodes(G, pos, node_size=sizes, ax=ax)
    draw_labels_with_font(ax, pos, labels, fontsize=11)
    ax.set_title(title, fontsize=13, fontproperties=FONT_PROP)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=220, bbox_inches="tight")
    plt.close(fig)

for g in ["사헌부", "사간원", "승정원", "의금부", "개인"]:
    cg = marker_pair_by_group.get(g, Counter())
    if sum(cg.values()) == 0:
        continue
    cr = overall_marker_pairs - cg
    z_pairs = log_odds_z_from_counts(cg, cr, alpha_base=overall_marker_pairs, alpha0=1.0)
    z_pairs.to_csv(os.path.join(OUTDIR, f"table_markerpair_logodds_{g}.csv"), encoding="utf-8-sig")

    top_edges = []
    for e, z in z_pairs.items():
        if cg.get(e, 0) >= 2 and z > 0:
            top_edges.append((e, z, cg.get(e, 0)))
    top_edges.sort(key=lambda x: x[1], reverse=True)
    top_edges = top_edges[:50]

    save_diff_network(top_edges,
                      f"{g}: 기관-특이 숫자↔표지 결합(차등 네트워크, log-odds z 상위)",
                      f"06_diff_network_{g}.png")

print("완료! 결과 폴더:", OUTDIR)
print("사용 폰트:", FONT_PATH, FONT_NAME)
