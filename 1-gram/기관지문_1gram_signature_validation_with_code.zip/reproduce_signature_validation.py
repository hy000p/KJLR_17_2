# -*- coding: utf-8 -*-
"""
4기관(사헌부/사간원/승정원/의금부) '기관 지문'의 타당성 검증: 1-gram만으로 기관 예측
- 입력: /mnt/data/조선시대 계회시 목록.xlsx (sheet: 계회시_저자)
- 핵심: 한자(Han) 1-gram + (보수적) 기능어 제거 + (옵션) 별칭 표지 보존(吾, 相)
- 산출:
  1) 5-fold 교차검증 성능 비교 그래프(PNG)
  2) 혼동행렬 2종(PNG)
  3) 분류 리포트(CSV)
  4) 기관별 상위 판별 토큰(=지문 후보) 표(CSV)
  5) (선택) 이전 log-odds 지문 결과와의 상위 토큰 교집합(CSV)
"""

import os
import shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import font_manager
import regex as re2

from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    confusion_matrix, ConfusionMatrixDisplay, classification_report,
    accuracy_score, f1_score
)

# =========================
# 0) 사용자 설정
# =========================
EXCEL_PATH = "/mnt/data/조선시대 계회시 목록.xlsx"
SHEET_NAME = "계회시_저자"
OUTPUT_DIR = "/mnt/data/기관지문_1gram_signature_validation"

OFFICES = ["사헌부", "사간원", "승정원", "의금부"]

STOPWORDS = "之 其 而 以 於 于 也 矣 焉 兮 乎 哉 者 所 乃 與 及 且 為 曰 云 則 非 無 有 不 復 亦 又 更 可 何 我 吾 爾 汝 彼 此 是 斯 相 諸 各 皆 每".split()
NUMERALS = "一 二 三 四 五 六 七 八 九 十 百 千 萬 兩 雙 第".split()

# 별칭 보존(기관 자기지시 표지 유지):
# - 金吾의 吾, 相臺의 相 등이 기능어 목록에 들어있으나 기관지문 목적상 중요
PRESERVE_ALIAS_CHARS = True
KEEP_FROM_STOP = set(list("吾相"))

# CJK 폰트(환경에 따라 경로 수정 가능)
CJK_FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"


# =========================
# 1) 유틸
# =========================
def setup_font():
    if os.path.exists(CJK_FONT_PATH):
        font_manager.fontManager.addfont(CJK_FONT_PATH)
        mpl.rcParams["font.family"] = font_manager.FontProperties(fname=CJK_FONT_PATH).get_name()
    mpl.rcParams["axes.unicode_minus"] = False


def build_stop_set():
    stop = set(STOPWORDS) - set(NUMERALS)
    if PRESERVE_ALIAS_CHARS:
        stop = stop - KEEP_FROM_STOP
    return stop


def tokenize_han(text: str, stop_set: set) -> list:
    chars = re2.findall(r"\p{Han}", str(text))
    return [c for c in chars if c not in stop_set]


# =========================
# 2) 메인
# =========================
def main():
    setup_font()
    stop_set = build_stop_set()

    # load
    df = pd.read_excel(EXCEL_PATH, sheet_name=SHEET_NAME)

    # filter 4 offices
    typ = df["유형"].astype(str).str.strip()
    df = df[typ.str.startswith(tuple(OFFICES))].copy()
    df["office"] = df["유형"].astype(str).str.strip().str.extract(r"^(사헌부|사간원|승정원|의금부)")[0]

    # tokenize -> document string
    df["tokens"] = df["원문"].map(lambda x: tokenize_han(x, stop_set))
    df["doc"] = df["tokens"].map(lambda toks: " ".join(toks))

    X_text = df["doc"].values
    y = df["office"].values

    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    labels = le.classes_

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # 모델 1: TF-IDF + Logistic Regression
    pipe_lr = Pipeline([
        ("tfidf", TfidfVectorizer(token_pattern=r"(?u)\b\w+\b", min_df=2)),
        ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", solver="liblinear")),
    ])
    pred_lr = cross_val_predict(pipe_lr, X_text, y_enc, cv=cv)
    acc_lr = accuracy_score(y_enc, pred_lr)
    f1_lr = f1_score(y_enc, pred_lr, average="macro")

    # 모델 2: Count + MultinomialNB
    pipe_nb = Pipeline([
        ("count", CountVectorizer(token_pattern=r"(?u)\b\w+\b", min_df=2)),
        ("clf", MultinomialNB(alpha=0.5)),
    ])
    pred_nb = cross_val_predict(pipe_nb, X_text, y_enc, cv=cv)
    acc_nb = accuracy_score(y_enc, pred_nb)
    f1_nb = f1_score(y_enc, pred_nb, average="macro")

    # output dir
    if os.path.exists(OUTPUT_DIR):
        shutil.rmtree(OUTPUT_DIR)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # metrics
    metrics = pd.DataFrame([
        {"model": "TF-IDF+LR", "accuracy": acc_lr, "macro_f1": f1_lr},
        {"model": "Count+NB", "accuracy": acc_nb, "macro_f1": f1_nb},
    ])
    metrics.to_csv(os.path.join(OUTPUT_DIR, "cv_metrics.csv"), index=False, encoding="utf-8-sig")

    # confusion matrices (PNG)
    cm_lr = confusion_matrix(y_enc, pred_lr)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm_lr, display_labels=labels)
    fig, ax = plt.subplots(figsize=(7, 6))
    disp.plot(ax=ax, values_format="d")
    ax.set_title("혼동행렬(5-fold CV): TF-IDF + 로지스틱 회귀")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, "confusion_matrix_lr.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    cm_nb = confusion_matrix(y_enc, pred_nb)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm_nb, display_labels=labels)
    fig, ax = plt.subplots(figsize=(7, 6))
    disp.plot(ax=ax, values_format="d")
    ax.set_title("혼동행렬(5-fold CV): Count + MultinomialNB")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, "confusion_matrix_nb.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    # model comparison (PNG)
    fig, ax = plt.subplots(figsize=(7, 4))
    models = ["TF-IDF+LR", "Count+NB"]
    accs = [acc_lr, acc_nb]
    f1s = [f1_lr, f1_nb]
    x = np.arange(len(models))
    width = 0.35
    ax.bar(x - width / 2, accs, width, label="Accuracy")
    ax.bar(x + width / 2, f1s, width, label="Macro F1")
    ax.set_xticks(x)
    ax.set_xticklabels(models)
    ax.set_ylim(0, 1.0)
    ax.set_title("기관 예측 성능(5-fold CV) — 1-gram만 사용")
    ax.legend()
    for i, v in enumerate(accs):
        ax.text(i - width / 2, v + 0.01, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    for i, v in enumerate(f1s):
        ax.text(i + width / 2, v + 0.01, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, "model_comparison_accuracy.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    # classification reports (CSV)
    rep_lr = classification_report(y_enc, pred_lr, target_names=labels, output_dict=True)
    pd.DataFrame(rep_lr).T.to_csv(os.path.join(OUTPUT_DIR, "classification_report_lr.csv"), encoding="utf-8-sig")
    rep_nb = classification_report(y_enc, pred_nb, target_names=labels, output_dict=True)
    pd.DataFrame(rep_nb).T.to_csv(os.path.join(OUTPUT_DIR, "classification_report_nb.csv"), encoding="utf-8-sig")

    # Fit LR on full data to list "판별 토큰"(해석용)
    pipe_lr.fit(X_text, y_enc)
    vec = pipe_lr.named_steps["tfidf"]
    clf = pipe_lr.named_steps["clf"]
    feat = np.array(vec.get_feature_names_out())
    coefs = clf.coef_  # (n_classes, n_features)

    topN = 25
    rows = []
    for i, lab in enumerate(labels):
        idx = np.argsort(coefs[i])[::-1][:topN]
        for r, j in enumerate(idx, start=1):
            rows.append({"office": lab, "rank": r, "token": feat[j], "coef": float(coefs[i][j])})
    topfeat = pd.DataFrame(rows)
    topfeat.to_csv(os.path.join(OUTPUT_DIR, "top_features_lr.csv"), index=False, encoding="utf-8-sig")

    # (선택) 이전 log-odds 지문 결과와 교집합(상위 25)
    sig_path = "/mnt/data/기관지문_1gram_signature/signature_top_tokens_logodds.csv"
    if os.path.exists(sig_path):
        sig = pd.read_csv(sig_path)
        sig_top = sig.sort_values(["office", "z"], ascending=[True, False]).groupby("office").head(25)

        ov = []
        for lab in labels:
            a = set(sig_top[sig_top.office == lab]["token"].tolist())
            b = set(topfeat[(topfeat.office == lab) & (topfeat["rank"] <= 25)]["token"].tolist())
            inter = sorted(list(a & b))
            ov.append({"office": lab, "overlap_top25": len(inter), "tokens_space_joined": " ".join(inter)})
        pd.DataFrame(ov).to_csv(os.path.join(OUTPUT_DIR, "signature_vs_lr_overlap.csv"),
                                index=False, encoding="utf-8-sig")

    print("Done. Outputs saved to:", OUTPUT_DIR)
    print(metrics)


if __name__ == "__main__":
    main()
