# -*- coding: utf-8 -*-
"""
1-gram(한자 1자) 기반 기관 지문 검증: 혼동행렬 생성
- 입력: /mnt/data/조선시대 계회시 목록.xlsx (sheet: 계회시_저자)
- 출력: /mnt/data/기관지문_1gram_signature_validation/confusion_matrix_lr.png
       /mnt/data/기관지문_1gram_signature_validation/confusion_matrix_nb.png
       + 분류 리포트 CSV 2종

모델
1) TF-IDF + Logistic Regression (One-vs-Rest)
2) Count + Multinomial Naive Bayes
평가
- 5-fold Stratified CV, cross_val_predict로 전체 혼동행렬 집계
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import font_manager
import regex as re2

from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    confusion_matrix, classification_report,
    ConfusionMatrixDisplay, accuracy_score, f1_score
)

EXCEL_PATH = "/mnt/data/조선시대 계회시 목록.xlsx"
SHEET_NAME = "계회시_저자"
OUTDIR = "/mnt/data/기관지문_1gram_signature_validation"

OFFICES = ["사헌부", "사간원", "승정원", "의금부"]

STOPWORDS = "之 其 而 以 於 于 也 矣 焉 兮 乎 哉 者 所 乃 與 及 且 為 曰 云 則 非 無 有 不 復 亦 又 更 可 何 我 吾 爾 汝 彼 此 是 斯 相 諸 各 皆 每".split()
NUMERALS = "一 二 三 四 五 六 七 八 九 十 百 千 萬 兩 雙 第".split()

# 기관 별칭 표지 보존(의금부 金吾의 吾, 사헌부 相臺의 相)
PRESERVE_ALIAS_CHARS = True
KEEP_FROM_STOP = set(list("吾相"))

CJK_FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"


def setup_font():
    if os.path.exists(CJK_FONT_PATH):
        font_manager.fontManager.addfont(CJK_FONT_PATH)
        mpl.rcParams["font.family"] = font_manager.FontProperties(fname=CJK_FONT_PATH).get_name()
    mpl.rcParams["axes.unicode_minus"] = False


def build_stop_set():
    stop = set(STOPWORDS) - set(NUMERALS)
    if PRESERVE_ALIAS_CHARS:
        stop = stop - KEEP_FROM_STOP
    return stop


def tokenize_han(text: str, stop_set: set):
    chars = re2.findall(r"\p{Han}", str(text))
    return [c for c in chars if c not in stop_set]


def save_cm(cm, labels, title, path):
    fig, ax = plt.subplots(figsize=(7, 6))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    disp.plot(ax=ax, values_format="d", cmap=None, colorbar=False)
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main():
    setup_font()
    os.makedirs(OUTDIR, exist_ok=True)

    df = pd.read_excel(EXCEL_PATH, sheet_name=SHEET_NAME)
    df = df[df["유형"].astype(str).str.strip().str.startswith(tuple(OFFICES))].copy()
    df["office"] = df["유형"].astype(str).str.strip().str.extract(r"^(사헌부|사간원|승정원|의금부)")[0]

    stop_set = build_stop_set()
    df["tokens"] = df["원문"].map(lambda x: tokenize_han(x, stop_set))
    df["doc"] = df["tokens"].map(lambda toks: " ".join(toks))

    X = df["doc"].values
    y = df["office"].values

    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    labels = le.classes_

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # (1) TF-IDF + LR
    pipe_lr = Pipeline([
        ("tfidf", TfidfVectorizer(token_pattern=r"(?u)\b\w+\b", min_df=2)),
        ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", solver="liblinear"))
    ])
    pred_lr = cross_val_predict(pipe_lr, X, y_enc, cv=cv)
    cm_lr = confusion_matrix(y_enc, pred_lr)
    save_cm(cm_lr, labels, "혼동행렬(5-fold CV): TF-IDF + 로지스틱 회귀",
            os.path.join(OUTDIR, "confusion_matrix_lr.png"))

    rep_lr = classification_report(y_enc, pred_lr, target_names=labels, output_dict=True)
    pd.DataFrame(rep_lr).T.to_csv(os.path.join(OUTDIR, "classification_report_lr.csv"),
                                  encoding="utf-8-sig")

    # (2) Count + MultinomialNB
    pipe_nb = Pipeline([
        ("count", CountVectorizer(token_pattern=r"(?u)\b\w+\b", min_df=2)),
        ("clf", MultinomialNB(alpha=0.5))
    ])
    pred_nb = cross_val_predict(pipe_nb, X, y_enc, cv=cv)
    cm_nb = confusion_matrix(y_enc, pred_nb)
    save_cm(cm_nb, labels, "혼동행렬(5-fold CV): Count + MultinomialNB",
            os.path.join(OUTDIR, "confusion_matrix_nb.png"))

    rep_nb = classification_report(y_enc, pred_nb, target_names=labels, output_dict=True)
    pd.DataFrame(rep_nb).T.to_csv(os.path.join(OUTDIR, "classification_report_nb.csv"),
                                  encoding="utf-8-sig")

    # 간단 요약 출력
    acc_lr = accuracy_score(y_enc, pred_lr)
    f1_lr = f1_score(y_enc, pred_lr, average="macro")
    acc_nb = accuracy_score(y_enc, pred_nb)
    f1_nb = f1_score(y_enc, pred_nb, average="macro")
    print(f"TF-IDF+LR  acc={acc_lr:.3f}, macroF1={f1_lr:.3f}")
    print(f"Count+NB   acc={acc_nb:.3f}, macroF1={f1_nb:.3f}")


if __name__ == "__main__":
    main()
