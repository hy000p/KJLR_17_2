# -*- coding: utf-8 -*-
"""
조선시대 계회시 목록(엑셀) - 숫자(一~萬/兩/雙/第) 1-gram 기관별 비교 + 문맥 기능(기록/연령/서열/수량) 분석
- 입력: 엑셀 첫 번째 sheet(계회시_저자)
- 출력: PNG 그래프 + CSV 테이블 (outdir 폴더)
작성: ChatGPT (재생산용 단일 스크립트)
"""

import os, re, math
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, findSystemFonts

# -----------------------------
# 0) 경로 설정
# -----------------------------
EXCEL_PATH = r"/mnt/data/조선시대 계회시 목록.xlsx"   # 필요 시 수정
OUTDIR = r"/mnt/data/number_analysis_outputs"        # 필요 시 수정
os.makedirs(OUTDIR, exist_ok=True)

# -----------------------------
# 1) 폰트 설정(한자 깨짐 방지)
# -----------------------------
def set_cjk_font():
    # 우선순위 후보
    candidates = [
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "/usr/share/fonts/truetype/nanum/NanumMyeongjoBold.ttf",
        "/usr/share/fonts/truetype/unfonts-core/UnBatang.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            name = FontProperties(fname=p).get_name()
            rcParams["font.family"] = name
            rcParams["axes.unicode_minus"] = False
            return p, name
    # 그래도 없으면 시스템 폰트 중 'Noto'/'Nanum' 탐색
    for p in findSystemFonts(fontext="ttf"):
        if ("Noto" in p) or ("Nanum" in p) or ("UnBatang" in p):
            name = FontProperties(fname=p).get_name()
            rcParams["font.family"] = name
            rcParams["axes.unicode_minus"] = False
            return p, name
    return None, None

FONT_PATH, FONT_NAME = set_cjk_font()

# -----------------------------
# 2) 데이터 로드
# -----------------------------
df = pd.read_excel(EXCEL_PATH, sheet_name=0)  # 첫 번째 sheet
df["유형"] = df["유형"].fillna("").astype(str)
df["원문"] = df["원문"].fillna("").astype(str)

OFFICES = ["사헌부", "사간원", "승정원", "의금부"]

def map_group(x: str) -> str:
    s = str(x).strip()
    if "0" in s:
        return "개인"
    for o in OFFICES:
        if s.startswith(o):
            return o
    return "기타관청"

df["기관"] = df["유형"].apply(map_group)

# -----------------------------
# 3) 전처리(한자만 유지) + 길이
# -----------------------------
NUM_TOKENS = list("一二三四五六七八九十百千萬兩雙第")
han_re = re.compile(r"[\u3007\u3400-\u4dbf\u4e00-\u9fff\uF900-\uFAFF]")  # 〇 포함

def clean_han(text: str) -> str:
    return "".join(han_re.findall(text))

df["clean"] = df["원문"].apply(clean_han)
df["len"] = df["clean"].str.len()

# -----------------------------
# 4) 기관별 숫자 1-gram 빈도(per-1k)
# -----------------------------
group_stats = []
for g, sub in df.groupby("기관"):
    total_tokens = int(sub["len"].sum())
    counts = Counter()
    for s in sub["clean"]:
        counts.update(s)
    row = {"기관": g, "총토큰": total_tokens}
    for t in NUM_TOKENS:
        row[t] = counts.get(t, 0)
        row[f"{t}_per1k"] = (counts.get(t, 0) / total_tokens * 1000) if total_tokens > 0 else 0.0
    group_stats.append(row)

gs = pd.DataFrame(group_stats).set_index("기관")

GROUP_ORDER = ["개인", "사헌부", "사간원", "승정원", "의금부", "기타관청"]

per1k = gs[[f"{t}_per1k" for t in NUM_TOKENS]].copy()
per1k.columns = NUM_TOKENS
per1k = per1k.reindex(GROUP_ORDER)

per1k.to_csv(os.path.join(OUTDIR, "table_num_per1k.csv"), encoding="utf-8-sig")

# -----------------------------
# 5) 숫자 문맥(기록/연령/서열/수량/기타) 자동 분류
# -----------------------------
WINDOW = 8

RECORD_MARKERS = set(list("年月日朔望晦旬初正元春夏秋冬晨夕夜曉午辰時更刻"))
QUANTITY_MARKERS = set(list("人員客僚友杯觴盞巡章篇首聲里丈尺畝戶隊名雙兩家"))
# 연령/서열은 별도 규칙(아래)

def classify_occ(token: str, ctx: str) -> str:
    # 우선순위: 연령 > 서열 > 기록(시간) > 수량 > 기타
    if token == "第":
        return "서열"
    # 연령
    if ("歲" in ctx) or ("齡" in ctx) or ("壽" in ctx) or ("春秋" in ctx):
        return "연령"
    if ("年" in ctx) and any(m in ctx for m in ["少", "老", "翁", "耆", "幼", "長"]):
        return "연령"
    # 서열(第+數, 次/序/班/席/位/品/等 등)
    if ("第" in ctx) or any(m in ctx for m in ["次", "序", "班", "席", "位", "品", "等", "行", "首", "亞"]):
        return "서열"
    # 기록(시간/연대/계절 등)
    if any(m in ctx for m in RECORD_MARKERS):
        return "기록"
    # 수량(인원/물량/횟수 등)
    if any(m in ctx for m in QUANTITY_MARKERS):
        return "수량"
    return "기타"

records = []
for _, row in df.iterrows():
    g = row["기관"]
    s = row["clean"]
    if not s:
        continue
    for i, ch in enumerate(s):
        if ch in NUM_TOKENS:
            left = max(0, i - WINDOW)
            right = min(len(s), i + WINDOW + 1)
            ctx = s[left:right]
            pos = i - left
            cat = classify_occ(ch, ctx)
            kwic = ctx[:pos] + "[" + ch + "]" + ctx[pos + 1:]
            records.append((g, ch, cat, kwic))

lab = pd.DataFrame(records, columns=["기관", "숫자", "범주", "KWIC"])
lab.to_csv(os.path.join(OUTDIR, "table_all_occurrences_kwic.csv"), index=False, encoding="utf-8-sig")

dist_counts = lab.pivot_table(index="기관", columns="범주", values="숫자", aggfunc="count", fill_value=0).reindex(GROUP_ORDER)
dist_pct = dist_counts.div(dist_counts.sum(axis=1), axis=0) * 100

dist_counts.to_csv(os.path.join(OUTDIR, "table_context_category_counts.csv"), encoding="utf-8-sig")
dist_pct.round(4).to_csv(os.path.join(OUTDIR, "table_context_category_pct.csv"), encoding="utf-8-sig")

# -----------------------------
# 6) 2-gram: 숫자 + 우측 1글자(문맥 단서)
# -----------------------------
def extract_right_bigrams(text: str):
    bigrams = []
    for i, ch in enumerate(text[:-1]):
        if ch in NUM_TOKENS:
            bigrams.append(ch + text[i + 1])
    return bigrams

df["num_right_bigram_list"] = df["clean"].apply(extract_right_bigrams)

bigram_counts_by_group = {}
overall = Counter()
for g, sub in df.groupby("기관"):
    c = Counter()
    for lst in sub["num_right_bigram_list"]:
        c.update(lst)
    bigram_counts_by_group[g] = c
    overall.update(c)

targets = ["一", "三", "七", "十", "第"]
top_target_bigrams = [bg for bg, _ in Counter({bg: overall[bg] for bg in overall if bg[0] in targets}).most_common(15)]

total_tokens_by_group = gs["총토큰"].to_dict()
bigram_mat = pd.DataFrame(index=GROUP_ORDER, columns=top_target_bigrams, dtype=float)
for g in GROUP_ORDER:
    c = bigram_counts_by_group.get(g, Counter())
    tot = total_tokens_by_group.get(g, 1)
    for bg in top_target_bigrams:
        bigram_mat.loc[g, bg] = c.get(bg, 0) / tot * 1000

bigram_mat.round(5).to_csv(os.path.join(OUTDIR, "table_target_bigrams_per1k.csv"), encoding="utf-8-sig")

# -----------------------------
# 7) 연속 숫자표현(예: 二十四, 十二, 第一) 추출
# -----------------------------
num_chars = "".join(NUM_TOKENS)
seq_re = re.compile(f"[{re.escape(num_chars)}]{{2,}}")

def extract_num_seqs(s: str):
    return seq_re.findall(s)

df["num_seq_list"] = df["clean"].apply(extract_num_seqs)

seq_counts_by_group = {}
overall_seq = Counter()
for g, sub in df.groupby("기관"):
    c = Counter()
    for lst in sub["num_seq_list"]:
        c.update(lst)
    seq_counts_by_group[g] = c
    overall_seq.update(c)

# -----------------------------
# 8) log-odds z (기관 vs 나머지)로 숫자 변별성 추정
# -----------------------------
counts_by_group = {}
overall_num = Counter()
for g, sub in df.groupby("기관"):
    c = Counter()
    for s in sub["clean"]:
        c.update([ch for ch in s if ch in NUM_TOKENS])
    counts_by_group[g] = c
    overall_num.update(c)

alpha0 = 1.0
total_overall = sum(overall_num.values())
alpha = {t: alpha0 * (overall_num.get(t, 0) + 1e-9) / total_overall for t in NUM_TOKENS}

def log_odds_z(group: str) -> pd.Series:
    c_g = np.array([counts_by_group[group].get(t, 0) for t in NUM_TOKENS], dtype=float)
    c_r = np.array([overall_num.get(t, 0) - counts_by_group[group].get(t, 0) for t in NUM_TOKENS], dtype=float)
    a = np.array([alpha[t] for t in NUM_TOKENS], dtype=float)
    n_g = c_g.sum()
    n_r = c_r.sum()
    lo_g = np.log((c_g + a) / (n_g + a.sum() - (c_g + a)))
    lo_r = np.log((c_r + a) / (n_r + a.sum() - (c_r + a)))
    delta = lo_g - lo_r
    var = 1 / (c_g + a) + 1 / (c_r + a)
    z = delta / np.sqrt(var)
    return pd.Series(z, index=NUM_TOKENS)

z_df = pd.DataFrame({g: log_odds_z(g) for g in ["사헌부", "사간원", "승정원", "의금부", "개인"]}).T
z_df.round(5).to_csv(os.path.join(OUTDIR, "table_logodds_z.csv"), encoding="utf-8-sig")

# -----------------------------
# 9) 시각화 저장 함수
# -----------------------------
def save_heatmap(mat_df: pd.DataFrame, title: str, filename: str, fmt: str = ".2f"):
    data = mat_df.values.astype(float)
    fig, ax = plt.subplots(figsize=(12, 4.5))
    im = ax.imshow(data, aspect="auto")
    ax.set_xticks(np.arange(mat_df.shape[1]))
    ax.set_xticklabels(mat_df.columns, fontsize=11)
    ax.set_yticks(np.arange(mat_df.shape[0]))
    ax.set_yticklabels(mat_df.index, fontsize=11)
    ax.set_title(title, fontsize=14)
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            ax.text(j, i, format(data[i, j], fmt),
                    ha="center", va="center", fontsize=8,
                    color="white" if data[i, j] > data.max() * 0.6 else "black")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="per 1,000 한자")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=200, bbox_inches="tight")
    plt.close(fig)

def save_grouped_bar(df_bar: pd.DataFrame, title: str, filename: str, ylabel: str = "per 1,000 한자"):
    fig, ax = plt.subplots(figsize=(12, 5))
    x = np.arange(len(df_bar.index))
    width = 0.15
    cols = list(df_bar.columns)
    for k, col in enumerate(cols):
        ax.bar(x + (k - (len(cols) - 1) / 2) * width, df_bar[col].values, width=width, label=col)
    ax.set_xticks(x)
    ax.set_xticklabels(df_bar.index, fontsize=11)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=14)
    ax.legend(ncol=len(cols), bbox_to_anchor=(0.5, 1.15), loc="upper center", frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=200, bbox_inches="tight")
    plt.close(fig)

def save_stacked_bar(pct_df: pd.DataFrame, title: str, filename: str, ylabel: str = "비율(%)"):
    fig, ax = plt.subplots(figsize=(12, 5))
    bottom = np.zeros(len(pct_df))
    x = np.arange(len(pct_df.index))
    for col in pct_df.columns:
        vals = pct_df[col].values
        ax.bar(x, vals, bottom=bottom, label=col)
        bottom += vals
    ax.set_xticks(x)
    ax.set_xticklabels(pct_df.index, fontsize=11)
    ax.set_ylabel(ylabel)
    ax.set_ylim(0, 100)
    ax.set_title(title, fontsize=14)
    ax.legend(ncol=len(pct_df.columns), bbox_to_anchor=(0.5, 1.15), loc="upper center", frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=200, bbox_inches="tight")
    plt.close(fig)

def save_top_items_bar(counter: Counter, title: str, filename: str, n: int = 12, xlabel: str = "출현 횟수"):
    items = counter.most_common(n)
    if not items:
        return
    labels = [k for k, v in items][::-1]
    vals = [v for k, v in items][::-1]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(range(len(labels)), vals)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=11)
    ax.set_xlabel(xlabel)
    ax.set_title(title, fontsize=14)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=200, bbox_inches="tight")
    plt.close(fig)

def save_z_bar(z_series: pd.Series, title: str, filename: str, topn: int = 10):
    s = z_series.sort_values(key=lambda x: np.abs(x), ascending=False).head(topn)
    s = s.sort_values()
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.barh(range(len(s)), s.values)
    ax.axvline(0, linewidth=1)
    ax.set_yticks(range(len(s)))
    ax.set_yticklabels(s.index, fontsize=11)
    ax.set_xlabel("log-odds z (기관 vs 나머지)")
    ax.set_title(title, fontsize=14)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTDIR, filename), dpi=200, bbox_inches="tight")
    plt.close(fig)

# -----------------------------
# 10) 그래프 저장
# -----------------------------
save_heatmap(per1k, "기관별 숫자 1-gram 빈도(토큰 1,000당)", "01_num_heatmap_per1k.png")
save_grouped_bar(per1k[targets], "주요 숫자(一/三/七/十/第) 기관별 비교", "02_target_nums_per1k.png")
save_stacked_bar(dist_pct[["기록", "연령", "서열", "수량", "기타"]],
                 "숫자 출현 문맥의 기능(기록/연령/서열/수량/기타) 기관별 비율",
                 "03_context_category_stacked_pct.png")
save_heatmap(bigram_mat, "주요 숫자-우측 결합(2-gram) 패턴 기관별 빈도(토큰 1,000당)",
             "04_target_bigrams_heatmap_per1k.png")

for g in ["개인", "사헌부", "사간원", "승정원", "의금부"]:
    save_top_items_bar(seq_counts_by_group.get(g, Counter()),
                       f"{g}에서 자주 쓰인 연속 숫자표현(예: 二十四, 十二)",
                       f"05_numseq_top_{g}.png", n=12)

for g in ["사헌부", "사간원", "승정원", "의금부", "개인"]:
    save_z_bar(z_df.loc[g], f"{g}: 숫자 사용의 변별성(log-odds z)", f"06_logodds_{g}.png", topn=10)

print("완료! 출력 폴더:", OUTDIR)
print("사용 폰트:", FONT_PATH, FONT_NAME)
