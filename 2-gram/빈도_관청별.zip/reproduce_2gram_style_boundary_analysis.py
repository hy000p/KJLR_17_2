# -*- coding: utf-8 -*-
"""Reproduce 2-gram analysis (meter-based; within line/phrase boundary).
Input: /mnt/data/조선시대 계회시 목록.xlsx
Output: /mnt/data/2gram_style_boundary_results (PNG + Excel)

Run:
  python reproduce_2gram_style_boundary_analysis.py
"""

import os, re, math
import numpy as np
import pandas as pd
from collections import Counter
import matplotlib.pyplot as plt
from matplotlib import font_manager

xlsx_path = r"/mnt/data/조선시대 계회시 목록.xlsx"
out_dir = r"/mnt/data/2gram_style_boundary_results"
os.makedirs(out_dir, exist_ok=True)

def pick_cjk_font():
    preferred = [
        "Noto Serif CJK KR", "Noto Sans CJK KR",
        "Noto Serif CJK JP", "Noto Sans CJK JP",
        "Noto Serif CJK SC", "Noto Sans CJK SC",
        "NanumGothic", "NanumMyeongjo",
        "AppleGothic", "SimHei", "MS Gothic"
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in preferred:
        if name in available:
            return name
    for name in available:
        if "Noto" in name and "CJK" in name:
            return name
    return None

cjk_font = pick_cjk_font()
if cjk_font:
    plt.rcParams["font.family"] = cjk_font
plt.rcParams["axes.unicode_minus"] = False

STOPWORDS = set(list("之其而以於于也矣焉兮乎哉者所乃與及且為曰云則非無有不復亦又更可何我吾爾汝彼此是斯相諸各皆每"))
NUMERALS = set(list("一二三四五六七八九十百千萬兩雙第"))
OFFICES = ["사헌부", "사간원", "승정원", "의금부"]

PUNC_SPLIT_RE = re.compile(r"[，。；？！：、,\.\;\:\?\!\s]+")
CJK_RE = re.compile(r"[\u3400-\u9FFF]")

def parse_meter(s):
    if pd.isna(s):
        return None
    m = re.search(r"([0-9]+)\s*언", str(s))
    if m:
        return int(m.group(1))
    m2 = re.findall(r"([0-9]+)\s*언", str(s))
    return int(m2[0]) if m2 else None

def segment_by_meter(text, meter):
    if pd.isna(text) or text is None:
        return []
    parts = [p for p in PUNC_SPLIT_RE.split(str(text)) if p]
    segments = []
    for part in parts:
        chars = CJK_RE.findall(part)
        if not chars:
            continue
        if meter and meter >= 2 and len(chars) > meter:
            if len(chars) % meter == 0:
                for i in range(0, len(chars), meter):
                    segments.append(chars[i:i+meter])
            elif len(chars) >= 2 * meter:
                i = 0
                while i + meter <= len(chars):
                    segments.append(chars[i:i+meter]); i += meter
                if i < len(chars):
                    segments.append(chars[i:])
            else:
                segments.append(chars)
        else:
            segments.append(chars)
    return segments

def extract_unigrams_bigrams(text, meter):
    segments = segment_by_meter(text, meter)
    unigrams, bigrams = [], []
    for seg in segments:
        unigrams.extend(seg)
        for i in range(len(seg)-1):
            bigrams.append(seg[i] + seg[i+1])
    return unigrams, bigrams

def filter_ngrams(unigrams, bigrams, drop_numerals=False):
    if drop_numerals:
        unigrams_f = [u for u in unigrams if (u not in STOPWORDS and u not in NUMERALS)]
        bigrams_f = [bg for bg in bigrams if (bg[0] not in STOPWORDS and bg[1] not in STOPWORDS and bg[0] not in NUMERALS and bg[1] not in NUMERALS)]
    else:
        unigrams_f = [u for u in unigrams if (u not in STOPWORDS)]
        bigrams_f = [bg for bg in bigrams if (bg[0] not in STOPWORDS and bg[1] not in STOPWORDS)]
    return unigrams_f, bigrams_f

def build_counts(df, mask, drop_numerals=False):
    uni = Counter(); bi = Counter(); docs = 0
    for _, r in df.loc[mask, ["원문", "meter"]].iterrows():
        u, b = extract_unigrams_bigrams(r["원문"], r["meter"])
        u, b = filter_ngrams(u, b, drop_numerals=drop_numerals)
        if not b:
            continue
        docs += 1
        uni.update(u); bi.update(b)
    return uni, bi, docs

def per1k(counter):
    total = sum(counter.values())
    return {k: v/total*1000 for k,v in counter.items()} if total else {}

def log_odds_z(c1, c2, alpha=0.01):
    vocab = set(c1) | set(c2)
    b = Counter(); b.update(c1); b.update(c2)
    if sum(b.values()) == 0:
        return {}
    alpha_w = {w: alpha * b[w] for w in vocab}
    alpha0 = sum(alpha_w.values())
    n1, n2 = sum(c1.values()), sum(c2.values())
    z = {}
    for w in vocab:
        aw = alpha_w[w]
        cw1 = c1.get(w,0) + aw
        cw2 = c2.get(w,0) + aw
        denom1 = (n1 + alpha0) - cw1
        denom2 = (n2 + alpha0) - cw2
        if cw1 <= 0 or cw2 <= 0 or denom1 <= 0 or denom2 <= 0:
            continue
        lo1 = math.log(cw1/denom1); lo2 = math.log(cw2/denom2)
        delta = lo1 - lo2
        var = 1.0/cw1 + 1.0/cw2
        z[w] = delta / math.sqrt(var)
    return z

def npmi_for_bigrams(uni_counts, bi_counts, min_count=2):
    total_uni, total_bi = sum(uni_counts.values()), sum(bi_counts.values())
    if total_uni == 0 or total_bi == 0:
        return {}
    out = {}
    for bg, cxy in bi_counts.items():
        if cxy < min_count:
            continue
        x, y = bg[0], bg[1]
        cx, cy = uni_counts.get(x,0), uni_counts.get(y,0)
        if cx == 0 or cy == 0:
            continue
        pxy = cxy/total_bi
        px = cx/total_uni
        py = cy/total_uni
        pmi = math.log(pxy/(px*py))
        out[bg] = pmi/(-math.log(pxy))
    return out

def composite_z_npmi(z_scores, npmi_scores, direction="pos"):
    if direction == "pos":
        items = [(w,z) for w,z in z_scores.items() if z > 0 and w in npmi_scores and npmi_scores[w] > 0]
        if not items: return {}
        npmis = np.array([npmi_scores[w] for w,_ in items], float)
        mu, sd = float(npmis.mean()), float(npmis.std(ddof=0) if npmis.std(ddof=0) > 1e-9 else 1.0)
        return {w: z + ((npmi_scores[w]-mu)/sd) for w,z in items}
    else:
        items = [(w,-z) for w,z in z_scores.items() if z < 0 and w in npmi_scores and npmi_scores[w] > 0]
        if not items: return {}
        npmis = np.array([npmi_scores[w] for w,_ in items], float)
        mu, sd = float(npmis.mean()), float(npmis.std(ddof=0) if npmis.std(ddof=0) > 1e-9 else 1.0)
        return {w: zabs + ((npmi_scores[w]-mu)/sd) for w,zabs in items}

def save_butterfly(perA, perB, A, B, top_each, title, filename):
    keys = set(perA) | set(perB)
    diffs = [(k, perA.get(k,0.0) - perB.get(k,0.0)) for k in keys]
    diffs.sort(key=lambda x:x[1], reverse=True)
    top_pos = diffs[:top_each]
    top_neg = sorted(diffs[-top_each:], key=lambda x:x[1])
    selected = top_pos + top_neg
    labels = [k for k,_ in selected]
    a_vals = [-perA.get(k,0.0) for k in labels]
    b_vals = [perB.get(k,0.0) for k in labels]
    y = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(10, max(6, len(labels)*0.35)))
    ax.barh(y, a_vals); ax.barh(y, b_vals)
    ax.axvline(0, linewidth=1)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=11)
    ax.invert_yaxis()
    ax.set_xlabel(f"per-1K bigrams (left negative={A}, right positive={B})")
    ax.set_title(title)
    mx = max(max(map(abs,a_vals)) if a_vals else 0, max(b_vals) if b_vals else 0) * 1.15
    ax.set_xlim(-mx, mx)
    for i,k in enumerate(labels):
        ax.text(a_vals[i]-mx*0.02, i, f"{perA.get(k,0):.2f}", va="center", ha="right", fontsize=9)
        ax.text(b_vals[i]+mx*0.02, i, f"{perB.get(k,0):.2f}", va="center", ha="left", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300); plt.close(fig)

def save_diverging(scores, pos_label, neg_label, top_each, title, filename):
    items = sorted(scores.items(), key=lambda x:x[1], reverse=True)
    top_pos = items[:top_each]
    top_neg = sorted(items[-top_each:], key=lambda x:x[1])
    selected = top_pos + top_neg
    labels = [k for k,_ in selected]
    vals = [v for _,v in selected]
    y = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(10, max(6, len(labels)*0.35)))
    ax.barh(y, vals)
    ax.axvline(0, linewidth=1)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=11)
    ax.invert_yaxis()
    ax.set_xlabel(f"score (+={pos_label}, −={neg_label})")
    ax.set_title(title)
    mx = max(abs(min(vals)), abs(max(vals))) * 1.15 if vals else 1
    ax.set_xlim(-mx, mx)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300); plt.close(fig)

def save_grid_top(scores_by_group, xlabel, title, filename, topn):
    fig, axes = plt.subplots(2,2, figsize=(14,12))
    axes = axes.ravel()
    for ax, o in zip(axes, OFFICES):
        scores = scores_by_group.get(o, {})
        items = sorted(scores.items(), key=lambda x:x[1], reverse=True)[:topn]
        labels = [k for k,_ in items][::-1]
        vals = [v for _,v in items][::-1]
        ax.barh(range(len(labels)), vals)
        ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels, fontsize=10)
        ax.set_title(o); ax.set_xlabel(xlabel)
    fig.suptitle(title, y=0.99, fontsize=16)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300); plt.close(fig)

# Load (first sheet)
df = pd.read_excel(xlsx_path, sheet_name=0)[["유형","문체","원문"]].copy()
df["유형"] = df["유형"].astype(str)
df["meter"] = df["문체"].apply(parse_meter)
df["group2"] = np.where(df["유형"].str.contains("0", regex=False), "개인", "관청")

def map_office(t):
    t = str(t).strip()
    for o in OFFICES:
        if t.startswith(o):
            return o
    return None
df["office4"] = df["유형"].apply(map_office)

# corpora
counts2 = {}
for g in ["개인","관청"]:
    uni, bi, docs = build_counts(df, df["group2"]==g, drop_numerals=False)
    counts2[g] = {"uni":uni, "bi":bi, "docs":docs}

counts4_with, counts4_nonum = {}, {}
for o in OFFICES:
    uni, bi, docs = build_counts(df, df["office4"]==o, drop_numerals=False)
    counts4_with[o] = {"uni":uni, "bi":bi, "docs":docs}
    uni2, bi2, docs2 = build_counts(df, df["office4"]==o, drop_numerals=True)
    counts4_nonum[o] = {"uni":uni2, "bi":bi2, "docs":docs2}

# 1) per1k
per2 = {g: per1k(counts2[g]["bi"]) for g in ["개인","관청"]}
save_butterfly(per2["개인"], per2["관청"], "개인", "관청", 15,
              "2-gram per-1K (문체 기반 행/구 경계 내부) — 개인 vs 관청",
              "01_per1k_private_vs_official_2gram.png")

def office_vs_rest_per1k(counts_dict):
    out = {}
    for o in OFFICES:
        bi_o = counts_dict[o]["bi"]
        bi_rest = Counter()
        for oo in OFFICES:
            if oo != o:
                bi_rest.update(counts_dict[oo]["bi"])
        per_o, per_r = per1k(bi_o), per1k(bi_rest)
        out[o] = {k: per_o.get(k,0)-per_r.get(k,0) for k in set(per_o)|set(per_r)}
    return out

diff4_with = office_vs_rest_per1k(counts4_with)
save_grid_top(diff4_with, "per-1K diff (office − others)",
              "2-gram per-1K 차이 (숫자 포함) — 4개 관청(각 관청 vs 나머지)",
              "02_per1k_office4_with_numbers_2gram.png", 20)

diff4_nonum = office_vs_rest_per1k(counts4_nonum)
save_grid_top(diff4_nonum, "per-1K diff (office − others)",
              "2-gram per-1K 차이 (숫자 제외) — 4개 관청(각 관청 vs 나머지)",
              "03_per1k_office4_no_numbers_2gram.png", 20)

# 2) log-odds z
z_pvso = log_odds_z(counts2["개인"]["bi"], counts2["관청"]["bi"], alpha=0.01)
save_diverging(z_pvso, "개인", "관청", 20,
              "2-gram log-odds z — 개인 vs 관청",
              "04_logodds_private_vs_official_2gram.png")

def office_vs_rest_logodds(counts_dict):
    out = {}
    for o in OFFICES:
        bi_o = counts_dict[o]["bi"]
        bi_rest = Counter()
        for oo in OFFICES:
            if oo != o:
                bi_rest.update(counts_dict[oo]["bi"])
        out[o] = log_odds_z(bi_o, bi_rest, alpha=0.01)
    return out

z4_with = office_vs_rest_logodds(counts4_with)
z4_with_pos = {o: {k:v for k,v in z.items() if v>0} for o,z in z4_with.items()}
save_grid_top(z4_with_pos, "log-odds z (office vs others)",
              "2-gram log-odds z (숫자 포함) — 4개 관청(각 관청 vs 나머지)",
              "05_logodds_office4_with_numbers_2gram.png", 20)

z4_nonum = office_vs_rest_logodds(counts4_nonum)
z4_nonum_pos = {o: {k:v for k,v in z.items() if v>0} for o,z in z4_nonum.items()}
save_grid_top(z4_nonum_pos, "log-odds z (office vs others)",
              "2-gram log-odds z (숫자 제외) — 4개 관청(각 관청 vs 나머지)",
              "06_logodds_office4_no_numbers_2gram.png", 20)

# 3) composite
npmi_priv = npmi_for_bigrams(counts2["개인"]["uni"], counts2["개인"]["bi"], min_count=2)
npmi_off = npmi_for_bigrams(counts2["관청"]["uni"], counts2["관청"]["bi"], min_count=2)

comp_priv = composite_z_npmi(z_pvso, npmi_priv, direction="pos")
comp_off = composite_z_npmi(z_pvso, npmi_off, direction="neg")
comp_signed = {**{k:v for k,v in comp_priv.items()}, **{k:-v for k,v in comp_off.items()}}
save_diverging(comp_signed, "개인", "관청", 20,
              "2-gram 복합점수 (log-odds z + NPMI[z-표준화]) — 개인 vs 관청",
              "07_z_npmi_private_vs_official_2gram.png")

def office_composite(counts_dict):
    out = {}
    for o in OFFICES:
        bi_o, uni_o = counts_dict[o]["bi"], counts_dict[o]["uni"]
        bi_rest = Counter()
        for oo in OFFICES:
            if oo != o:
                bi_rest.update(counts_dict[oo]["bi"])
        z = log_odds_z(bi_o, bi_rest, alpha=0.01)
        npmi_o = npmi_for_bigrams(uni_o, bi_o, min_count=2)
        out[o] = composite_z_npmi(z, npmi_o, direction="pos")
    return out

comp4_with = office_composite(counts4_with)
save_grid_top(comp4_with, "composite = z + NPMI(z-표준화)",
              "2-gram 복합점수 (숫자 포함) — 4개 관청(각 관청 vs 나머지)",
              "08_z_npmi_office4_with_numbers_2gram.png", 20)

comp4_nonum = office_composite(counts4_nonum)
save_grid_top(comp4_nonum, "composite = z + NPMI(z-표준화)",
              "2-gram 복합점수 (숫자 제외) — 4개 관청(각 관청 vs 나머지)",
              "09_z_npmi_office4_no_numbers_2gram.png", 20)

# tables
table_path = os.path.join(out_dir, "top_bigrams_tables.xlsx")
def topn_dict_to_df(d, metric, topn=30):
    rows=[]
    for o in OFFICES:
        for bg, sc in sorted(d.get(o,{}).items(), key=lambda x:x[1], reverse=True)[:topn]:
            rows.append([o, bg, sc])
    return pd.DataFrame(rows, columns=["office","2gram",metric])

keys = set(per2["개인"]) | set(per2["관청"])
perdiff = {k: per2["개인"].get(k,0)-per2["관청"].get(k,0) for k in keys}
t_per_pos = pd.DataFrame(sorted(perdiff.items(), key=lambda x:x[1], reverse=True)[:30], columns=["2gram","per1k_diff(개인-관청)"])
t_per_neg = pd.DataFrame(sorted(perdiff.items(), key=lambda x:x[1])[:30], columns=["2gram","per1k_diff(개인-관청)"])
t_z_pos = pd.DataFrame(sorted(z_pvso.items(), key=lambda x:x[1], reverse=True)[:30], columns=["2gram","logodds_z(+개인)"])
t_z_neg = pd.DataFrame(sorted(z_pvso.items(), key=lambda x:x[1])[:30], columns=["2gram","logodds_z(+개인)"])
t_c_pos = pd.DataFrame(sorted(comp_signed.items(), key=lambda x:x[1], reverse=True)[:30], columns=["2gram","composite(+개인)"])
t_c_neg = pd.DataFrame(sorted(comp_signed.items(), key=lambda x:x[1])[:30], columns=["2gram","composite(+개인)"])

t_off_per_with = topn_dict_to_df(diff4_with, "per1k_diff_withNum")
t_off_per_nonum = topn_dict_to_df(diff4_nonum, "per1k_diff_noNum")
t_off_z_with = topn_dict_to_df(z4_with_pos, "logodds_z_withNum")
t_off_z_nonum = topn_dict_to_df(z4_nonum_pos, "logodds_z_noNum")
t_off_c_with = topn_dict_to_df(comp4_with, "composite_withNum")
t_off_c_nonum = topn_dict_to_df(comp4_nonum, "composite_noNum")

with pd.ExcelWriter(table_path) as w:
    t_per_pos.to_excel(w, sheet_name="per1k_private_top", index=False)
    t_per_neg.to_excel(w, sheet_name="per1k_official_top", index=False)
    t_z_pos.to_excel(w, sheet_name="logodds_private_top", index=False)
    t_z_neg.to_excel(w, sheet_name="logodds_official_top", index=False)
    t_c_pos.to_excel(w, sheet_name="composite_private_top", index=False)
    t_c_neg.to_excel(w, sheet_name="composite_official_top", index=False)
    t_off_per_with.to_excel(w, sheet_name="office_per1k_withNum", index=False)
    t_off_per_nonum.to_excel(w, sheet_name="office_per1k_noNum", index=False)
    t_off_z_with.to_excel(w, sheet_name="office_logodds_withNum", index=False)
    t_off_z_nonum.to_excel(w, sheet_name="office_logodds_noNum", index=False)
    t_off_c_with.to_excel(w, sheet_name="office_comp_withNum", index=False)
    t_off_c_nonum.to_excel(w, sheet_name="office_comp_noNum", index=False)

print("Done. Output directory:", out_dir)
