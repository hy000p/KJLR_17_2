# -*- coding: utf-8 -*-
"""Reproduce:
(A) Office-alias dictionary analysis (within meter/punct boundary; no cross-boundary matching)
(B) Numeric 2-gram discourse analysis (within boundary)

Input:
  /mnt/data/조선시대 계회시 목록.xlsx

Output directory:
  /mnt/data/2gram_style_boundary_extensions

Run:
  python reproduce_alias_numeric_extensions.py

Notes:
- 2-gram extraction is constrained to within segmented units determined by punctuation/newlines,
  and additionally chunked by meter length (5/7/4/6...) when segments are long.
- Stopwords list is the conservative functional list from the project guide.
- Numerals (一二...第) are NOT removed; numeric analyses focus on bigrams where either char is numeral.
"""

import os, re, math, zipfile
import numpy as np
import pandas as pd
from collections import Counter
import matplotlib.pyplot as plt
from matplotlib import font_manager

xlsx_path = r"/mnt/data/조선시대 계회시 목록.xlsx"
out_dir = r"/mnt/data/2gram_style_boundary_extensions"
os.makedirs(out_dir, exist_ok=True)

# ---------- Font ----------
def pick_cjk_font():
    preferred = [
        "Noto Serif CJK KR", "Noto Sans CJK KR",
        "Noto Serif CJK JP", "Noto Sans CJK JP",
        "Noto Serif CJK SC", "Noto Sans CJK SC",
        "NanumGothic", "NanumMyeongjo",
        "AppleGothic", "SimHei", "MS Gothic"
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in preferred:
        if name in available:
            return name
    for name in available:
        if "Noto" in name and "CJK" in name:
            return name
    return None

cjk_font = pick_cjk_font()
if cjk_font:
    plt.rcParams["font.family"] = cjk_font
plt.rcParams["axes.unicode_minus"] = False

# ---------- Lexica / rules ----------
STOPWORDS = set(list("之其而以於于也矣焉兮乎哉者所乃與及且為曰云則非無有不復亦又更可何我吾爾汝彼此是斯相諸各皆每"))
NUMERALS = set(list("一二三四五六七八九十百千萬兩雙第"))
OFFICES = ["사헌부", "사간원", "승정원", "의금부"]

# Office alias terms (2+ chars; we count them as substrings within bounded segments)
OFFICE_ALIASES = {
    "사헌부": ["驄馬", "憲府", "栢府", "相臺", "烏臺", "御史臺", "監察司", "臺官", "大官", "臺諫"],
    "사간원": ["薇院", "諫院", "大諫", "臺諫", "薇垣", "言路"],
    "승정원": ["銀臺", "政院", "喉院", "代言司", "承旨", "喉舌", "絲綸"],
    "의금부": ["金吾", "金部", "禁府", "王府", "詔獄", "推鞫"]
}
OFFICE_ALIASES = {k: sorted(set(v), key=lambda x:(len(x), x)) for k,v in OFFICE_ALIASES.items()}
ALIAS_TERMS_ALL = sorted(set(sum([v for v in OFFICE_ALIASES.values()], [])), key=lambda x:(len(x), x))

PUNC_SPLIT_RE = re.compile(r"[，。；？！：、,\.\;\:\?\!\s]+")
CJK_RE = re.compile(r"[\u3400-\u9FFF]")

# ---------- Meter / segmentation ----------
def parse_meter(s):
    if pd.isna(s):
        return None
    m = re.search(r"([0-9]+)\s*언", str(s))
    if m:
        try:
            return int(m.group(1))
        except:
            return None
    m2 = re.findall(r"([0-9]+)\s*언", str(s))
    return int(m2[0]) if m2 else None

def segment_by_meter(text, meter):
    """Split by punctuation/newlines; chunk long segments by meter length when sensible."""
    if pd.isna(text) or text is None:
        return []
    parts = [p for p in PUNC_SPLIT_RE.split(str(text)) if p]
    segments = []
    for part in parts:
        chars = CJK_RE.findall(part)
        if not chars:
            continue
        if meter and meter >= 2 and len(chars) > meter:
            if len(chars) % meter == 0:
                for i in range(0, len(chars), meter):
                    segments.append(chars[i:i+meter])
            elif len(chars) >= 2 * meter:
                i = 0
                while i + meter <= len(chars):
                    segments.append(chars[i:i+meter]); i += meter
                if i < len(chars):
                    segments.append(chars[i:])
            else:
                segments.append(chars)
        else:
            segments.append(chars)
    return segments

def extract_unigrams_bigrams(text, meter):
    segs = segment_by_meter(text, meter)
    unigrams, bigrams = [], []
    for seg in segs:
        unigrams.extend(seg)
        for i in range(len(seg)-1):
            bigrams.append(seg[i] + seg[i+1])
    return segs, unigrams, bigrams

def filter_ngrams(unigrams, bigrams, drop_numerals=False):
    if drop_numerals:
        u = [x for x in unigrams if (x not in STOPWORDS and x not in NUMERALS)]
        b = [bg for bg in bigrams if (bg[0] not in STOPWORDS and bg[1] not in STOPWORDS and bg[0] not in NUMERALS and bg[1] not in NUMERALS)]
    else:
        u = [x for x in unigrams if (x not in STOPWORDS)]
        b = [bg for bg in bigrams if (bg[0] not in STOPWORDS and bg[1] not in STOPWORDS)]
    return u, b

# ---------- Load data ----------
df = pd.read_excel(xlsx_path, sheet_name=0)[["유형","문체","원문"]].copy()
df["유형"] = df["유형"].astype(str)
df["meter"] = df["문체"].apply(parse_meter)
df["group2"] = np.where(df["유형"].str.contains("0", regex=False), "개인", "관청")

def map_office(t):
    t = str(t).strip()
    for o in OFFICES:
        if t.startswith(o):
            return o
    return None
df["office4"] = df["유형"].apply(map_office)

# ---------- Corpus counts ----------
def build_counts(mask, drop_numerals=False):
    uni = Counter(); bi = Counter(); total_bi = 0; docs = 0
    for _, r in df.loc[mask, ["원문","meter"]].iterrows():
        _, u, b = extract_unigrams_bigrams(r["원문"], r["meter"])
        u, b = filter_ngrams(u, b, drop_numerals=drop_numerals)
        if not b:
            continue
        docs += 1
        uni.update(u); bi.update(b); total_bi += len(b)
    return {"uni": uni, "bi": bi, "total_bi": total_bi, "docs": docs}

counts2 = {g: build_counts(df["group2"]==g, drop_numerals=False) for g in ["개인","관청"]}
counts4 = {o: build_counts(df["office4"]==o, drop_numerals=False) for o in OFFICES}

# ---------- Metrics ----------
def per1k_subset(counter_subset, total_bi):
    if total_bi == 0:
        return {}
    return {k: v/total_bi*1000 for k,v in counter_subset.items()}

def log_odds_z(c1, c2, alpha=0.01):
    vocab = set(c1) | set(c2)
    b = Counter(); b.update(c1); b.update(c2)
    if sum(b.values()) == 0:
        return {}
    alpha_w = {w: alpha * b[w] for w in vocab}
    alpha0 = sum(alpha_w.values())
    n1, n2 = sum(c1.values()), sum(c2.values())
    z = {}
    for w in vocab:
        aw = alpha_w[w]
        cw1 = c1.get(w,0) + aw
        cw2 = c2.get(w,0) + aw
        denom1 = (n1 + alpha0) - cw1
        denom2 = (n2 + alpha0) - cw2
        if cw1 <= 0 or cw2 <= 0 or denom1 <= 0 or denom2 <= 0:
            continue
        lo1 = math.log(cw1/denom1); lo2 = math.log(cw2/denom2)
        delta = lo1 - lo2
        var = 1.0/cw1 + 1.0/cw2
        z[w] = delta / math.sqrt(var)
    return z

def npmi_for_bigrams(uni_counts, bi_counts, min_count=2):
    total_uni, total_bi = sum(uni_counts.values()), sum(bi_counts.values())
    if total_uni == 0 or total_bi == 0:
        return {}
    out = {}
    for bg, cxy in bi_counts.items():
        if cxy < min_count:
            continue
        x, y = bg[0], bg[1]
        cx, cy = uni_counts.get(x,0), uni_counts.get(y,0)
        if cx == 0 or cy == 0:
            continue
        pxy = cxy/total_bi
        px = cx/total_uni
        py = cy/total_uni
        pmi = math.log(pxy/(px*py))
        out[bg] = pmi/(-math.log(pxy))
    return out

def composite_z_npmi(z_scores, npmi_scores, direction="pos"):
    if direction == "pos":
        items = [(w,z) for w,z in z_scores.items() if z>0 and w in npmi_scores and npmi_scores[w]>0]
        if not items:
            return {}
        npmis = np.array([npmi_scores[w] for w,_ in items], float)
        mu = float(npmis.mean())
        sd = float(npmis.std(ddof=0) if npmis.std(ddof=0) > 1e-9 else 1.0)
        return {w: z + ((npmi_scores[w]-mu)/sd) for w,z in items}
    else:
        items = [(w,-z) for w,z in z_scores.items() if z<0 and w in npmi_scores and npmi_scores[w]>0]
        if not items:
            return {}
        npmis = np.array([npmi_scores[w] for w,_ in items], float)
        mu = float(npmis.mean())
        sd = float(npmis.std(ddof=0) if npmis.std(ddof=0) > 1e-9 else 1.0)
        return {w: zabs + ((npmi_scores[w]-mu)/sd) for w,zabs in items}

# ---------- Plot helpers ----------
def save_barh(labels, vals, title, xlabel, filename, height_scale=0.35, annotate=True):
    fig, ax = plt.subplots(figsize=(10, max(5, len(labels)*height_scale)))
    ax.barh(range(len(labels)), vals)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=11)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    if annotate:
        for i,v in enumerate(vals):
            ax.text(v, i, f" {v:.2f}", va="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300)
    plt.close(fig)

def save_butterfly(perA, perB, A, B, top_each, title, filename):
    keys = set(perA) | set(perB)
    diffs = [(k, perA.get(k,0.0) - perB.get(k,0.0)) for k in keys]
    diffs.sort(key=lambda x:x[1], reverse=True)
    top_pos = diffs[:top_each]
    top_neg = sorted(diffs[-top_each:], key=lambda x:x[1])
    selected = top_pos + top_neg
    labels = [k for k,_ in selected]
    a_vals = [-perA.get(k,0.0) for k in labels]
    b_vals = [perB.get(k,0.0) for k in labels]
    y = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(10, max(6, len(labels)*0.35)))
    ax.barh(y, a_vals)
    ax.barh(y, b_vals)
    ax.axvline(0, linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=11)
    ax.invert_yaxis()
    ax.set_xlabel(f"per-1K (left={A}, right={B})")
    ax.set_title(title)
    mx = max(max(map(abs,a_vals)) if a_vals else 0, max(b_vals) if b_vals else 0) * 1.15
    ax.set_xlim(-mx, mx)
    for i,k in enumerate(labels):
        ax.text(a_vals[i]-mx*0.02, i, f"{perA.get(k,0):.2f}", va="center", ha="right", fontsize=9)
        ax.text(b_vals[i]+mx*0.02, i, f"{perB.get(k,0):.2f}", va="center", ha="left", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300)
    plt.close(fig)

def save_grid_barh(dict_by_office, title, xlabel, filename, topn=12):
    fig, axes = plt.subplots(2,2, figsize=(14,12))
    axes = axes.ravel()
    for ax, o in zip(axes, OFFICES):
        items = sorted(dict_by_office.get(o, {}).items(), key=lambda x:x[1], reverse=True)[:topn]
        labels = [k for k,_ in items][::-1]
        vals = [v for _,v in items][::-1]
        ax.barh(range(len(labels)), vals)
        ax.set_yticks(range(len(labels)))
        ax.set_yticklabels(labels, fontsize=10)
        ax.set_title(o)
        ax.set_xlabel(xlabel)
    fig.suptitle(title, y=0.99, fontsize=16)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300)
    plt.close(fig)

def save_heatmap(matrix, row_labels, col_labels, title, filename):
    mat = np.array(matrix, dtype=float)
    fig, ax = plt.subplots(figsize=(max(8, len(col_labels)*1.0), max(6, len(row_labels)*0.35)))
    im = ax.imshow(mat, aspect="auto")
    ax.set_xticks(np.arange(len(col_labels)))
    ax.set_xticklabels(col_labels, fontsize=11)
    ax.set_yticks(np.arange(len(row_labels)))
    ax.set_yticklabels(row_labels, fontsize=11)
    ax.set_title(title)
    plt.colorbar(im, ax=ax, fraction=0.02, pad=0.02)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, filename), dpi=300)
    plt.close(fig)

# =========================================================
# (A) Alias / signature dictionary
# =========================================================
def count_terms_within_segments(text, meter, terms):
    segs = segment_by_meter(text, meter)
    counts = Counter()
    for seg in segs:
        s = "".join(seg)
        for t in terms:
            start = 0
            while True:
                idx = s.find(t, start)
                if idx == -1:
                    break
                counts[t] += 1
                start = idx + 1
    return counts

alias_counts_group = {g: Counter() for g in ["개인","관청"]}
alias_counts_office = {o: Counter() for o in OFFICES}

for _, r in df.iterrows():
    if pd.isna(r["원문"]):
        continue
    c = count_terms_within_segments(r["원문"], r["meter"], ALIAS_TERMS_ALL)
    if not c:
        continue
    alias_counts_group[r["group2"]].update(c)
    if r["office4"] in OFFICES:
        alias_counts_office[r["office4"]].update(c)

alias_per1k_group = {g: per1k_subset(alias_counts_group[g], counts2[g]["total_bi"]) for g in ["개인","관청"]}
alias_per1k_office = {o: per1k_subset(alias_counts_office[o], counts4[o]["total_bi"]) for o in OFFICES}

save_butterfly(alias_per1k_group["개인"], alias_per1k_group["관청"],
               "개인","관청", 12,
               "기관 별칭/핵심어(사전 기반) per-1K — 개인 vs 관청",
               "A1_alias_per1k_private_vs_official.png")

save_grid_barh(alias_per1k_office,
               "기관 별칭/핵심어(사전 기반) per-1K — 4개 관청",
               "per-1K (occurrences / 1K bigrams)",
               "A2_alias_per1k_office4_grid.png",
               topn=12)

cols = ["개인","관청"] + OFFICES
heat = []
for t in ALIAS_TERMS_ALL:
    heat.append([
        alias_per1k_group["개인"].get(t,0.0),
        alias_per1k_group["관청"].get(t,0.0),
        alias_per1k_office["사헌부"].get(t,0.0),
        alias_per1k_office["사간원"].get(t,0.0),
        alias_per1k_office["승정원"].get(t,0.0),
        alias_per1k_office["의금부"].get(t,0.0),
    ])
save_heatmap(heat, ALIAS_TERMS_ALL, cols,
             "기관 별칭/핵심어 per-1K 분포(사전 기반; 행/구 경계 내부)",
             "A3_alias_heatmap_per1k.png")

alias_sig_z = {}
for o in OFFICES:
    c1 = alias_counts_office[o]
    c2 = Counter()
    for oo in OFFICES:
        if oo != o:
            c2.update(alias_counts_office[oo])
    z = log_odds_z(c1, c2, alpha=0.01)
    alias_sig_z[o] = {k:v for k,v in z.items() if v>0}

save_grid_barh(alias_sig_z,
               "기관 지문 후보(별칭 사전 내) — log-odds z (각 관청 vs 나머지)",
               "log-odds z",
               "A4_alias_signature_logodds_office4_grid.png",
               topn=10)

# =========================================================
# (B) Numeric 2-gram discourse
# =========================================================
def is_numeric_bigram(bg):
    return (bg[0] in NUMERALS) or (bg[1] in NUMERALS)

def is_pure_numeral_bigram(bg):
    return (bg[0] in NUMERALS) and (bg[1] in NUMERALS)

num_bi_group = {g: Counter({bg:c for bg,c in counts2[g]["bi"].items() if is_numeric_bigram(bg)}) for g in ["개인","관청"]}
num_bi_office = {o: Counter({bg:c for bg,c in counts4[o]["bi"].items() if is_numeric_bigram(bg)}) for o in OFFICES}

per_num_group = {g: per1k_subset(num_bi_group[g], counts2[g]["total_bi"]) for g in ["개인","관청"]}
save_butterfly(per_num_group["개인"], per_num_group["관청"],
               "개인","관청", 15,
               "숫자 포함 2-gram per-1K — 개인 vs 관청 (문체 기반 경계 내부)",
               "B1_numeric_per1k_private_vs_official.png")

# office vs rest per-1K diff (positive only)
num_perdiff_office = {}
for o in OFFICES:
    per_o = per1k_subset(num_bi_office[o], counts4[o]["total_bi"])
    rest = Counter(); rest_total = 0
    for oo in OFFICES:
        if oo != o:
            rest.update(num_bi_office[oo])
            rest_total += counts4[oo]["total_bi"]
    per_r = per1k_subset(rest, rest_total)
    diff = {k: per_o.get(k,0.0) - per_r.get(k,0.0) for k in set(per_o)|set(per_r)}
    num_perdiff_office[o] = {k:v for k,v in diff.items() if v>0}

save_grid_barh(num_perdiff_office,
               "숫자 포함 2-gram per-1K 차이 — 4개 관청(각 관청 vs 나머지)",
               "per-1K diff (office − others)",
               "B2_numeric_per1k_office4_grid.png",
               topn=12)

# log-odds z numeric-only
z_num_pvso = log_odds_z(num_bi_group["개인"], num_bi_group["관청"], alpha=0.01)
items = sorted(z_num_pvso.items(), key=lambda x:x[1], reverse=True)
selected = items[:20] + sorted(items[-20:], key=lambda x:x[1])
labels = [k for k,_ in selected][::-1]
vals = [v for _,v in selected][::-1]
save_barh(labels, vals, "숫자 포함 2-gram log-odds z — 개인(+) vs 관청(−)", "log-odds z",
          "B3_numeric_logodds_private_vs_official.png", height_scale=0.32)

z_num_office = {}
for o in OFFICES:
    c1 = num_bi_office[o]
    c2 = Counter()
    for oo in OFFICES:
        if oo != o:
            c2.update(num_bi_office[oo])
    z = log_odds_z(c1, c2, alpha=0.01)
    z_num_office[o] = {k:v for k,v in z.items() if v>0}

save_grid_barh(z_num_office,
               "숫자 포함 2-gram log-odds z — 4개 관청(각 관청 vs 나머지)",
               "log-odds z",
               "B4_numeric_logodds_office4_grid.png",
               topn=12)

# composite z+NPMI (numeric)
npmi_priv_all = npmi_for_bigrams(counts2["개인"]["uni"], counts2["개인"]["bi"], min_count=2)
npmi_off_all  = npmi_for_bigrams(counts2["관청"]["uni"], counts2["관청"]["bi"], min_count=2)
npmi_priv_num = {k:v for k,v in npmi_priv_all.items() if is_numeric_bigram(k)}
npmi_off_num  = {k:v for k,v in npmi_off_all.items() if is_numeric_bigram(k)}

comp_priv_num = composite_z_npmi(z_num_pvso, npmi_priv_num, direction="pos")
comp_off_num  = composite_z_npmi(z_num_pvso, npmi_off_num, direction="neg")
comp_signed_num = {**{k:v for k,v in comp_priv_num.items()}, **{k:-v for k,v in comp_off_num.items()}}

items = sorted(comp_signed_num.items(), key=lambda x:x[1], reverse=True)
selected = items[:20] + sorted(items[-20:], key=lambda x:x[1])
labels = [k for k,_ in selected][::-1]
vals = [v for _,v in selected][::-1]
save_barh(labels, vals, "숫자 포함 2-gram 복합점수(z+NPMI) — 개인(+) vs 관청(−)", "composite score",
          "B5_numeric_composite_private_vs_official.png", height_scale=0.32)

# office composite (positive only)
comp_num_office = {}
for o in OFFICES:
    c1 = num_bi_office[o]
    c2 = Counter()
    for oo in OFFICES:
        if oo != o:
            c2.update(num_bi_office[oo])
    z = log_odds_z(c1, c2, alpha=0.01)
    npmi_o_all = npmi_for_bigrams(counts4[o]["uni"], counts4[o]["bi"], min_count=2)
    npmi_o_num = {k:v for k,v in npmi_o_all.items() if is_numeric_bigram(k)}
    comp_num_office[o] = composite_z_npmi(z, npmi_o_num, direction="pos")

save_grid_barh(comp_num_office,
               "숫자 포함 2-gram 복합점수(z+NPMI) — 4개 관청(각 관청 vs 나머지)",
               "composite = z + NPMI(z-표준화)",
               "B6_numeric_composite_office4_grid.png",
               topn=12)

# numeral-marker heatmap (exactly one numeral in bigram)
marker_counter = Counter()
pair_counts_office = {o: Counter() for o in OFFICES}
for o in OFFICES:
    for bg, c in num_bi_office[o].items():
        a,b = bg[0], bg[1]
        if (a in NUMERALS) ^ (b in NUMERALS):
            num = a if a in NUMERALS else b
            mark = b if a in NUMERALS else a
            if mark in STOPWORDS or mark in NUMERALS:
                continue
            marker_counter[mark] += c
            pair_counts_office[o][(num, mark)] += c

top_markers = [m for m,_ in marker_counter.most_common(12)]
numeral_counter = Counter()
for o in OFFICES:
    for (num, mark), c in pair_counts_office[o].items():
        numeral_counter[num] += c
top_numerals = [n for n,_ in numeral_counter.most_common(10)]

fig, axes = plt.subplots(2,2, figsize=(16,12))
axes = axes.ravel()
last_im = None
for ax, o in zip(axes, OFFICES):
    mat = np.zeros((len(top_numerals), len(top_markers)), dtype=float)
    denom = max(counts4[o]["total_bi"], 1)
    for i,num in enumerate(top_numerals):
        for j,mk in enumerate(top_markers):
            mat[i,j] = pair_counts_office[o].get((num,mk), 0) / denom * 1000
    last_im = ax.imshow(mat, aspect="auto")
    ax.set_xticks(np.arange(len(top_markers))); ax.set_xticklabels(top_markers, fontsize=10)
    ax.set_yticks(np.arange(len(top_numerals))); ax.set_yticklabels(top_numerals, fontsize=10)
    ax.set_title(o); ax.set_xlabel("marker"); ax.set_ylabel("numeral")
fig.suptitle("숫자–표지(인접) per-1K 히트맵(문체 기반 경계 내부) — 4개 관청", y=0.99, fontsize=16)
fig.colorbar(last_im, ax=axes.tolist(), fraction=0.02, pad=0.02)
fig.tight_layout()
fig.savefig(os.path.join(out_dir, "B7_numeral_marker_heatmap_office4.png"), dpi=300)
plt.close(fig)

# pure numeral bigrams
pure_num_per_office = {}
for o in OFFICES:
    pure = Counter({bg:c for bg,c in num_bi_office[o].items() if is_pure_numeral_bigram(bg)})
    pure_num_per_office[o] = per1k_subset(pure, counts4[o]["total_bi"])

save_grid_barh(pure_num_per_office,
               "숫자-숫자 2-gram(per-1K) — 4개 관청",
               "per-1K (pure numeral bigrams)",
               "B8_pure_numeral_bigrams_office4_grid.png",
               topn=10)

# ---- Tables ----
tables_xlsx = os.path.join(out_dir, "tables_alias_numeric_extensions.xlsx")
with pd.ExcelWriter(tables_xlsx) as w:
    pd.DataFrame(sorted(alias_per1k_group["개인"].items(), key=lambda x:x[1], reverse=True),
                 columns=["alias_term","per1k_private"]).to_excel(w, sheet_name="alias_per1k_private", index=False)
    pd.DataFrame(sorted(alias_per1k_group["관청"].items(), key=lambda x:x[1], reverse=True),
                 columns=["alias_term","per1k_official"]).to_excel(w, sheet_name="alias_per1k_official", index=False)
    for o in OFFICES:
        pd.DataFrame(sorted(alias_per1k_office[o].items(), key=lambda x:x[1], reverse=True),
                     columns=["alias_term","per1k"]).to_excel(w, sheet_name=f"alias_{o}"[:31], index=False)
        pd.DataFrame(sorted(alias_sig_z[o].items(), key=lambda x:x[1], reverse=True),
                     columns=["alias_term","logodds_z"]).to_excel(w, sheet_name=f"alias_sigz_{o}"[:31], index=False)

    pd.DataFrame(sorted(per_num_group["개인"].items(), key=lambda x:x[1], reverse=True),
                 columns=["2gram","per1k_private"]).to_excel(w, sheet_name="numeric_per1k_private", index=False)
    pd.DataFrame(sorted(per_num_group["관청"].items(), key=lambda x:x[1], reverse=True),
                 columns=["2gram","per1k_official"]).to_excel(w, sheet_name="numeric_per1k_official", index=False)
    pd.DataFrame(sorted(z_num_pvso.items(), key=lambda x:x[1], reverse=True),
                 columns=["2gram","logodds_z(+private)"]).to_excel(w, sheet_name="numeric_logodds_pvso", index=False)
    pd.DataFrame(sorted(comp_signed_num.items(), key=lambda x:x[1], reverse=True),
                 columns=["2gram","composite(+private)"]).to_excel(w, sheet_name="numeric_composite_pvso", index=False)
    for o in OFFICES:
        pd.DataFrame(sorted(z_num_office[o].items(), key=lambda x:x[1], reverse=True),
                     columns=["2gram","logodds_z"]).to_excel(w, sheet_name=f"numeric_sigz_{o}"[:31], index=False)
        pd.DataFrame(sorted(comp_num_office[o].items(), key=lambda x:x[1], reverse=True),
                     columns=["2gram","composite"]).to_excel(w, sheet_name=f"numeric_comp_{o}"[:31], index=False)

print("Done. Outputs saved to:", out_dir)
