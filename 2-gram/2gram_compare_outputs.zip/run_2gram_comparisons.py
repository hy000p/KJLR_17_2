# -*- coding: utf-8 -*-
"""
조선시대 계회시(첫 번째 sheet: '계회시_저자') 기반 2-gram 비교 분석
- 기능어/수사(보수적) 제거
- 기본 분석은 '숫자(一二三...第 및 0-9)'를 제거하지 않음 (지침 준수)
- 단, 4관청 비교에서는 추가로 '숫자 제외' 버전을 함께 생성

산출물: PNG 그래프(출력 폴더에 저장)
"""

import os, re, math
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

# =========================
# 0) 환경/폰트 설정 (한자 깨짐 방지)
# =========================
# 환경에 따라 폰트명이 다를 수 있습니다. 아래 후보 중 설치된 것이 있으면 자동 적용됩니다.
CJK_FONT_CANDIDATES = [
    "Noto Sans CJK JP", "Noto Sans CJK KR", "Noto Serif CJK JP", "Noto Serif CJK KR",
    "NanumGothic", "NanumMyeongjo", "Baekmuk Batang"
]
available_fonts = set([f.name for f in mpl.font_manager.fontManager.ttflist])
for f in CJK_FONT_CANDIDATES:
    if f in available_fonts:
        mpl.rcParams["font.family"] = f
        break
mpl.rcParams["axes.unicode_minus"] = False

# =========================
# 1) 입력/출력 경로
# =========================
EXCEL_PATH = r"/mnt/data/조선시대 계회시 목록.xlsx"  # 필요 시 수정
OUTDIR = r"/mnt/data/2gram_compare_outputs"         # 필요 시 수정
os.makedirs(OUTDIR, exist_ok=True)

# =========================
# 2) 지침 기반 전처리 설정
# =========================
STOPWORDS = set("之 其 而 以 於 于 也 矣 焉 兮 乎 哉 者 所 乃 與 及 且 為 曰 云 則 非 無 有 不 復 亦 又 更 可 何 我 吾 爾 汝 彼 此 是 斯 相 諸 各 皆 每".split())
DIGIT_CHARS = set("一 二 三 四 五 六 七 八 九 十 百 千 萬 兩 雙 第".split())

OFFICES = ["사간원","사헌부","승정원","의금부"]

def is_cjk(ch: str) -> bool:
    o = ord(ch)
    return (0x3400 <= o <= 0x4DBF) or (0x4E00 <= o <= 0x9FFF) or (0xF900 <= o <= 0xFAFF)

def is_digit_token(ch: str) -> bool:
    return ch.isdigit() or (ch in DIGIT_CHARS)

def iter_tokens_with_boundaries(text: str):
    """
    한 글자씩 스캔:
      - CJK(한자) 또는 0-9 이면 토큰
      - 그 외(공백/구두점/줄바꿈 등)는 경계(None)로 처리하여 bigram이 문장/구두점 경계를 넘어가지 않게 함
    """
    for ch in text:
        if is_cjk(ch) or ch.isdigit():
            yield ch
        else:
            yield None

def count_unigrams_bigrams(text: str, remove_stopwords=True, remove_numbers=False):
    """
    중요:
      - bigram은 '원문 인접'을 유지하기 위해, 토큰을 제거하더라도 경계 처리(prev=None)로 연결이 이어지지 않게 함
    """
    uni = Counter()
    bi = Counter()
    prev = None
    for tok in iter_tokens_with_boundaries(text):
        if tok is None:
            prev = None
            continue

        if remove_stopwords and tok in STOPWORDS:
            prev = None
            continue

        if remove_numbers and is_digit_token(tok):
            prev = None
            continue

        uni[tok] += 1
        if prev is not None:
            bi[prev + tok] += 1
        prev = tok
    return uni, bi

def aggregate_counts(df_subset: pd.DataFrame, remove_numbers: bool):
    uni = Counter()
    bi = Counter()
    for txt in df_subset["원문"].astype(str):
        u, b = count_unigrams_bigrams(txt, remove_stopwords=True, remove_numbers=remove_numbers)
        uni.update(u); bi.update(b)
    return uni, bi

def per1k_bigram_counts(bi_counts: Counter, total_tokens: int):
    total_tokens = max(1, int(total_tokens))
    return {k: (v / total_tokens * 1000.0) for k, v in bi_counts.items()}

def log_odds_z(counts_a: Counter, counts_b: Counter, prior_counts: Counter):
    """
    Monroe et al.(2008) 방식의 log-odds z-score.
    - prior_counts: 정보 사전(informative Dirichlet prior)로, 보통 비교대상 두 집단의 합을 사용.
    """
    vocab = set(counts_a) | set(counts_b)
    alpha0 = float(sum(prior_counts.values()))
    n_a = float(sum(counts_a.values()))
    n_b = float(sum(counts_b.values()))

    out = {}
    for w in vocab:
        c_a = float(counts_a.get(w, 0.0))
        c_b = float(counts_b.get(w, 0.0))
        a_w = float(prior_counts.get(w, 0.0))

        num_a = c_a + a_w
        num_b = c_b + a_w
        denom_a = (n_a - c_a) + (alpha0 - a_w)
        denom_b = (n_b - c_b) + (alpha0 - a_w)

        delta = math.log(num_a / denom_a) - math.log(num_b / denom_b)
        var = 1.0 / num_a + 1.0 / num_b
        z = delta / math.sqrt(var)
        out[w] = z
    return out

def compute_npmi_bigram_space(bi_counts: Counter, min_count=2):
    """
    NPMI (Normalized PMI)
    - bigram의 표본공간(빅그램 위치)을 기준으로 p(x), p(y), p(xy)를 계산해 [-1,1] 범위로 안정화.
    """
    total_bi = float(sum(bi_counts.values()))
    left = Counter()
    right = Counter()
    for bg, c in bi_counts.items():
        if len(bg) < 2:
            continue
        left[bg[0]] += c
        right[bg[1]] += c

    npmi = {}
    for bg, c_xy in bi_counts.items():
        if c_xy < min_count:
            continue
        x, y = bg[0], bg[1]
        p_xy = c_xy / total_bi
        p_x = left[x] / total_bi
        p_y = right[y] / total_bi
        pmi = math.log(p_xy / (p_x * p_y))
        val = pmi / (-math.log(p_xy))
        npmi[bg] = max(-1.0, min(1.0, val))
    return npmi

# =========================
# 3) 시각화 함수 (matplotlib 기본색 사용)
# =========================
def save_barh(items, title, xlabel, filepath, topn=20):
    labels = [k for k, v in items[:topn]][::-1]
    values = [v for k, v in items[:topn]][::-1]
    plt.figure(figsize=(8, max(4, 0.35 * len(labels) + 1.5)))
    plt.barh(range(len(labels)), values)
    plt.yticks(range(len(labels)), labels, fontsize=11)
    plt.xlabel(xlabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(filepath, dpi=220)
    plt.close()

def save_diverging_bar(items, title, xlabel, filepath, topn=25):
    items_sorted = sorted(items, key=lambda x: abs(x[1]), reverse=True)[:topn]
    labels = [k for k, v in items_sorted][::-1]
    values = [v for k, v in items_sorted][::-1]
    plt.figure(figsize=(9, max(4, 0.35 * len(labels) + 1.8)))
    plt.axvline(0, linewidth=1)
    plt.barh(range(len(labels)), values)
    plt.yticks(range(len(labels)), labels, fontsize=11)
    plt.xlabel(xlabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(filepath, dpi=220)
    plt.close()

def save_dumbbell(labels, x1, x2, label1, label2, title, xlabel, filepath):
    y = np.arange(len(labels))
    plt.figure(figsize=(9, max(4, 0.35 * len(labels) + 1.8)))
    for i in range(len(labels)):
        plt.plot([x1[i], x2[i]], [y[i], y[i]], linewidth=1)
    plt.scatter(x1, y, label=label1)
    plt.scatter(x2, y, label=label2)
    plt.yticks(y, labels, fontsize=11)
    plt.xlabel(xlabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filepath, dpi=220)
    plt.close()

def save_heatmap(matrix, row_labels, col_labels, title, xlabel, ylabel, filepath):
    mat = np.array(matrix, dtype=float)
    plt.figure(figsize=(8, max(4, 0.28 * len(row_labels) + 2)))
    im = plt.imshow(mat, aspect="auto")
    plt.colorbar(im)
    plt.xticks(range(len(col_labels)), col_labels, rotation=0)
    plt.yticks(range(len(row_labels)), row_labels, fontsize=10)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(filepath, dpi=220)
    plt.close()

# =========================
# 4) 데이터 로드 및 그룹 라벨링
# =========================
df = pd.read_excel(EXCEL_PATH, sheet_name=0)[["유형","원문"]].copy()
df["유형"] = df["유형"].astype(str)
df["원문"] = df["원문"].astype(str)

# 개인/관청: '유형'에 0 포함이면 개인
df["group_pers_off"] = np.where(df["유형"].str.contains("0"), "개인", "관청")

def office_label(t: str):
    t = str(t).strip()
    for o in OFFICES:
        if t.startswith(o):
            return o
    return None

df["office"] = df["유형"].apply(office_label)

# =========================
# 5) (1) 1,000토큰 정규화 빈도 비교
# =========================
# 전체 상위
uni_all, bi_all = aggregate_counts(df, remove_numbers=False)
per1k_all = per1k_bigram_counts(bi_all, sum(uni_all.values()))
top_overall = sorted(per1k_all.items(), key=lambda x: x[1], reverse=True)[:25]
save_barh(top_overall, "2-gram 전체 상위 빈도 (기능어 제거, 숫자 포함)", "빈도(1,000토큰당)",
          os.path.join(OUTDIR, "01_overall_top25_per1k.png"), topn=25)

# 개인 vs 관청
uni_p, bi_p = aggregate_counts(df[df.group_pers_off=="개인"], remove_numbers=False)
uni_o, bi_o = aggregate_counts(df[df.group_pers_off=="관청"], remove_numbers=False)
per1k_p = per1k_bigram_counts(bi_p, sum(uni_p.values()))
per1k_o = per1k_bigram_counts(bi_o, sum(uni_o.values()))

all_bigrams = set(per1k_p) | set(per1k_o)
diff = {bg: per1k_o.get(bg, 0.0) - per1k_p.get(bg, 0.0) for bg in all_bigrams}
top_diff = sorted(diff.items(), key=lambda x: abs(x[1]), reverse=True)[:20]
labels = [bg for bg, _ in top_diff][::-1]
x_off = [per1k_o.get(bg, 0.0) for bg in labels]
x_per = [per1k_p.get(bg, 0.0) for bg in labels]

save_dumbbell(labels, x_per, x_off, "개인", "관청",
              "2-gram 개인 vs 관청: 빈도(1,000토큰당) 비교 (차이가 큰 항목)",
              "빈도(1,000토큰당)",
              os.path.join(OUTDIR, "02_per1k_dumbbell_personal_vs_official.png"))

save_diverging_bar(list(diff.items()),
                   "2-gram 개인(-) / 관청(+) : 빈도 차이(관청-개인, 1,000토큰당)",
                   "빈도 차이(1,000토큰당)",
                   os.path.join(OUTDIR, "03_per1k_divergingdiff_personal_vs_official.png"),
                   topn=30)

# 4관청 빈도 히트맵 (숫자 포함)
office_counts = {}
per1k_off = {}
for o in OFFICES:
    subset = df[df.office == o]
    uni, bi = aggregate_counts(subset, remove_numbers=False)
    office_counts[o] = (uni, bi)
    per1k_off[o] = per1k_bigram_counts(bi, sum(uni.values()))

all_off_bigrams = set()
for o in OFFICES:
    all_off_bigrams |= set(per1k_off[o].keys())
max_rate = {bg: max(per1k_off[o].get(bg, 0.0) for o in OFFICES) for bg in all_off_bigrams}
top_heat = [bg for bg, _ in sorted(max_rate.items(), key=lambda x: x[1], reverse=True)[:30]]
mat = [[per1k_off[o].get(bg, 0.0) for o in OFFICES] for bg in top_heat]
save_heatmap(mat, top_heat, OFFICES,
             "4관청 2-gram 빈도 히트맵 (기능어 제거, 숫자 포함; 상위 30)",
             "관청", "2-gram",
             os.path.join(OUTDIR, "06_per1k_heatmap_4offices.png"))

# =========================
# 6) (2) log-odds z
# =========================
prior_po = Counter(); prior_po.update(bi_p); prior_po.update(bi_o)
z_off_vs_per = log_odds_z(bi_o, bi_p, prior_counts=prior_po)  # (+)관청, (-)개인
save_diverging_bar(list(z_off_vs_per.items()),
                   "2-gram 개인(-) / 관청(+): log-odds z (정보사전 priors)",
                   "log-odds z",
                   os.path.join(OUTDIR, "04_logoddsZ_personal_vs_official.png"),
                   topn=30)

# 4관청: 각 관청 vs 나머지 3관청 (숫자 포함)
pooled_bi = Counter()
for o in OFFICES:
    pooled_bi.update(office_counts[o][1])

office_z = {}
for o in OFFICES:
    bi_a = office_counts[o][1]
    bi_b = Counter()
    for o2 in OFFICES:
        if o2 != o:
            bi_b.update(office_counts[o2][1])
    z = log_odds_z(bi_a, bi_b, prior_counts=pooled_bi)  # (+)해당 관청
    office_z[o] = z
    top_pos = sorted([(bg, val) for bg, val in z.items() if val > 0], key=lambda x: x[1], reverse=True)[:25]
    save_barh(top_pos, f"{o}: log-odds z (vs. 다른 3관청)", "log-odds z",
              os.path.join(OUTDIR, f"07_logoddsZ_{o}_vs_other3.png"), topn=25)

# =========================
# 7) (3) log-odds z + NPMI 결합
# =========================
npmi_p = compute_npmi_bigram_space(bi_p, min_count=2)
npmi_o = compute_npmi_bigram_space(bi_o, min_count=2)

signed_comb = {}
for bg, z in z_off_vs_per.items():
    if z > 0:
        signed_comb[bg] = z * npmi_o.get(bg, 0.0)              # 관청(+)
    else:
        signed_comb[bg] = -((-z) * npmi_p.get(bg, 0.0))        # 개인(-)

save_diverging_bar(list(signed_comb.items()),
                   "2-gram 개인(-) / 관청(+): (log-odds z × NPMI) 결합 점수",
                   "결합 점수",
                   os.path.join(OUTDIR, "05_logoddsZxNPMI_personal_vs_official.png"),
                   topn=30)

# 4관청 결합 점수 (숫자 포함)
for o in OFFICES:
    bi_a = office_counts[o][1]
    npmi_a = compute_npmi_bigram_space(bi_a, min_count=2)
    z = office_z[o]
    comb = {bg: zval * npmi_a.get(bg, 0.0) for bg, zval in z.items() if zval > 0}
    topc = sorted(comb.items(), key=lambda x: x[1], reverse=True)[:25]
    save_barh(topc, f"{o}: (log-odds z × NPMI) (vs. 다른 3관청)", "결합 점수",
              os.path.join(OUTDIR, f"08_logoddsZxNPMI_{o}_vs_other3.png"), topn=25)

# =========================
# 8) 4관청 '숫자 제외' 추가 버전 (요구사항)
# =========================
office_counts_nonum = {}
per1k_off_nonum = {}
for o in OFFICES:
    subset = df[df.office == o]
    uni, bi = aggregate_counts(subset, remove_numbers=True)
    office_counts_nonum[o] = (uni, bi)
    per1k_off_nonum[o] = per1k_bigram_counts(bi, sum(uni.values()))

# 빈도 히트맵(숫자 제외)
all_off_bigrams2 = set()
for o in OFFICES:
    all_off_bigrams2 |= set(per1k_off_nonum[o].keys())
max_rate2 = {bg: max(per1k_off_nonum[o].get(bg, 0.0) for o in OFFICES) for bg in all_off_bigrams2}
top_heat2 = [bg for bg, _ in sorted(max_rate2.items(), key=lambda x: x[1], reverse=True)[:30]]
mat2 = [[per1k_off_nonum[o].get(bg, 0.0) for o in OFFICES] for bg in top_heat2]
save_heatmap(mat2, top_heat2, OFFICES,
             "4관청 2-gram 빈도 히트맵 (기능어 제거, 숫자 제외; 상위 30)",
             "관청", "2-gram",
             os.path.join(OUTDIR, "09_per1k_heatmap_4offices_no_numbers.png"))

# log-odds z 및 결합점수(숫자 제외)
pooled_bi_nonum = Counter()
for o in OFFICES:
    pooled_bi_nonum.update(office_counts_nonum[o][1])

for o in OFFICES:
    bi_a = office_counts_nonum[o][1]
    bi_b = Counter()
    for o2 in OFFICES:
        if o2 != o:
            bi_b.update(office_counts_nonum[o2][1])

    z = log_odds_z(bi_a, bi_b, prior_counts=pooled_bi_nonum)
    top_pos = sorted([(bg, val) for bg, val in z.items() if val > 0], key=lambda x: x[1], reverse=True)[:25]
    save_barh(top_pos, f"{o}: log-odds z (숫자 제외; vs. 다른 3관청)", "log-odds z",
              os.path.join(OUTDIR, f"10_logoddsZ_{o}_vs_other3_no_numbers.png"), topn=25)

    npmi_a = compute_npmi_bigram_space(bi_a, min_count=2)
    comb = {bg: zval * npmi_a.get(bg, 0.0) for bg, zval in z.items() if zval > 0}
    topc = sorted(comb.items(), key=lambda x: x[1], reverse=True)[:25]
    save_barh(topc, f"{o}: (log-odds z × NPMI) (숫자 제외; vs. 다른 3관청)", "결합 점수",
              os.path.join(OUTDIR, f"11_logoddsZxNPMI_{o}_vs_other3_no_numbers.png"), topn=25)

print("Done. Saved outputs to:", OUTDIR)
