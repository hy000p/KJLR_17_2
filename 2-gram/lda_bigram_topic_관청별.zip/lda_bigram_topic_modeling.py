# -*- coding: utf-8 -*-
"""
조선시대 계회시(엑셀 1st sheet) 2-gram 기반 LDA 토픽 모델링 (재현 코드)
- 문체(4/5/6/7언) 기반 + 행/구 경계(구두점) 내부에서만 2-gram 추출
- K 선택: (토픽 coherence: NPMI) + (토픽 distinctiveness: log-odds z) 결합
- 분석 A) 개인 vs 관청   B) 4개 관청(사헌부/사간원/승정원/의금부)
- 산출물: PNG + CSV + HTML(토픽표)

실행:
    python lda_bigram_topic_modeling.py --data "조선시대 계회시 목록.xlsx" --outdir "lda_bigram_topic_results"

필요 패키지:
    pandas numpy openpyxl scikit-learn matplotlib
"""

import os, re, math, argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer

# -----------------------------
# Config
# -----------------------------
STOPWORDS = set("之 其 而 以 於 于 也 矣 焉 兮 乎 哉 者 所 乃 與 及 且 為 曰 云 則 非 無 有 不 復 亦 又 更 可 何 我 吾 爾 汝 彼 此 是 斯 相 諸 各 皆 每".split())
NUM_KEEP = set("一 二 三 四 五 六 七 八 九 十 百 千 萬 兩 雙 第".split())
BOUNDARY_RE = re.compile(r"[。！？；\n\r\t，、,:：]")
HAN_RE = re.compile(r"[\u4e00-\u9fff]")

# K grid (빠른 탐색용: 5점)
K_GRID = [4, 6, 8, 10, 12]

def set_cjk_font():
    """Prefer Noto CJK JP to avoid missing Hanja glyphs."""
    candidates = ["Noto Sans CJK JP", "Noto Serif CJK JP", "NanumMyeongjo", "NanumGothic"]
    avail = {f.name for f in font_manager.fontManager.ttflist}
    for name in candidates:
        if name in avail:
            plt.rcParams["font.family"] = name
            plt.rcParams["axes.unicode_minus"] = False
            return name
    plt.rcParams["axes.unicode_minus"] = False
    return None

def parse_styleN(style):
    if pd.isna(style):
        return None
    s = str(style)
    m = re.findall(r"[0-9]", s)
    if m:
        return int(m[0])
    m = re.findall(r"[四六五七]", s)
    if m:
        mp = {'四':4,'五':5,'六':6,'七':7}
        return mp[m[0]]
    return None

def extract_bigrams(text, styleN=None):
    """Style-aware, within-line boundary bigrams."""
    if not isinstance(text, str) or not text.strip():
        return []
    styleN_int = None
    if styleN is not None and not pd.isna(styleN):
        try:
            styleN_int = int(styleN)
        except Exception:
            styleN_int = None

    segs = [s.strip() for s in BOUNDARY_RE.split(text) if s.strip()]
    out = []
    for seg in segs:
        chars = [c for c in seg if HAN_RE.match(c)]
        if not chars:
            continue

        # If missing punctuation, prevent cross-line bigrams by chunking with style length.
        if styleN_int in (4,5,6,7) and len(chars) > styleN_int:
            chunks = [chars[i:i+styleN_int] for i in range(0, len(chars), styleN_int)]
        else:
            chunks = [chars]

        for ch in chunks:
            for i in range(len(ch) - 1):
                a, b = ch[i], ch[i+1]
                if (a in STOPWORDS and a not in NUM_KEEP) or (b in STOPWORDS and b not in NUM_KEEP):
                    continue
                out.append(a + b)
    return out

def office4_label(t):
    s = str(t)
    for off in ["사헌부", "사간원", "승정원", "의금부"]:
        if s.startswith(off):
            return off
    return None

def build_vec(texts, min_df, max_df):
    vec = CountVectorizer(
        tokenizer=str.split, preprocessor=None, lowercase=False, token_pattern=None,
        min_df=min_df, max_df=max_df
    )
    X = vec.fit_transform(texts)
    return vec, X

def X_binary(X):
    Xb = X.copy()
    Xb.data = np.ones_like(Xb.data)
    return Xb

def topic_npmi(top_ids, Xb, eps=1e-12):
    """Doc-level NPMI coherence."""
    ids = list(top_ids)
    if len(ids) < 2:
        return np.nan
    sub = Xb[:, ids]
    co = (sub.T @ sub).toarray()
    N = Xb.shape[0]
    df_diag = np.diag(co)
    p = df_diag / N
    vals = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            dfij = co[i, j]
            if dfij <= 0:
                continue
            pij = dfij / N
            pmi = math.log((pij + eps) / ((p[i] + eps) * (p[j] + eps)))
            vals.append(pmi / (-math.log(pij + eps)))
    return float(np.mean(vals)) if vals else np.nan

def logodds_z_topic_vs_rest(components, k, prior_scale=0.05):
    """Monroe-style log-odds z: topic k vs rest."""
    comps = components
    total = comps.sum(axis=0)
    total_sum = total.sum()
    alpha = total * prior_scale + 1e-9
    alpha0 = alpha.sum()

    c1 = comps[k]; n1 = c1.sum()
    c2 = total - c1; n2 = total_sum - n1

    delta = np.log((c1 + alpha) / (n1 - c1 + (alpha0 - alpha))) - np.log((c2 + alpha) / (n2 - c2 + (alpha0 - alpha)))
    var = 1 / (c1 + alpha) + 1 / (c2 + alpha)
    return delta / np.sqrt(var)

def lda_fit(X, K, max_iter=20, rs=42):
    lda = LatentDirichletAllocation(
        n_components=K,
        learning_method="online",
        max_iter=max_iter,
        batch_size=128,
        learning_decay=0.7,
        learning_offset=10.0,
        random_state=rs,
        evaluate_every=-1,
        n_jobs=1  # 안정성(멀티프로세싱 오버헤드 방지)
    )
    lda.fit(X)
    return lda

def select_K(texts, K_grid, min_df, max_df, outdir, top_m=10, max_iter=20, title_prefix="model"):
    vec, X = build_vec(texts, min_df, max_df)
    Xb = X_binary(X)
    rows = []
    models = {}
    for K in K_grid:
        lda = lda_fit(X, K, max_iter=max_iter)
        models[K] = lda
        tw = lda.components_ / lda.components_.sum(axis=1, keepdims=True)
        top_ids = np.argsort(tw, axis=1)[:, ::-1][:, :top_m]
        coh = np.nanmean([topic_npmi(top_ids[k], Xb) for k in range(K)])
        dist = []
        for k in range(K):
            z = logodds_z_topic_vs_rest(lda.components_, k, prior_scale=0.05)
            dist.append(float(np.mean(np.abs(z[top_ids[k]]))))
        dist = float(np.mean(dist))
        rows.append({"K": K, "npmi": coh, "logodds_dist": dist})

    score = pd.DataFrame(rows).sort_values("K").reset_index(drop=True)
    score["npmi_z"] = (score["npmi"] - score["npmi"].mean()) / (score["npmi"].std(ddof=0) + 1e-12)
    score["dist_z"] = (score["logodds_dist"] - score["logodds_dist"].mean()) / (score["logodds_dist"].std(ddof=0) + 1e-12)
    score["combined"] = score["npmi_z"] + score["dist_z"]

    maxc = score["combined"].max()
    thr = maxc - 0.25 * (score["combined"].std(ddof=0) + 1e-12)
    bestK = int(score[score["combined"] >= thr]["K"].min())

    # plot
    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111)
    ax.plot(score["K"], score["npmi"], marker="o", label="NPMI")
    ax.plot(score["K"], score["logodds_dist"], marker="o", label="avg |log-odds z|")
    ax.plot(score["K"], score["combined"], marker="o", label="combined (z+z)")
    ax.axvline(bestK, linestyle="--", linewidth=1)
    ax.set_xlabel("K")
    ax.set_title(f"{title_prefix}: K selection (best K={bestK})")
    ax.legend()
    fig.tight_layout()
    kplot_path = os.path.join(outdir, f"{title_prefix}_k_selection.png")
    fig.savefig(kplot_path, dpi=300)
    plt.close(fig)

    return bestK, score, kplot_path, vec, X, models

def topic_terms_df(lda, vocab, top_n=20):
    tw = lda.components_ / lda.components_.sum(axis=1, keepdims=True)
    K = tw.shape[0]
    rows = []
    for k in range(K):
        ids = np.argsort(tw[k])[::-1][:top_n]
        rows.append({
            "topic": k,
            "top_terms": " ".join(vocab[ids]),
            "top_probs": " ".join([f"{tw[k,i]:.3f}" for i in ids]),
        })
    return pd.DataFrame(rows)

def plot_top_terms(lda, vocab, outpath, title, top_n=12):
    tw = lda.components_ / lda.components_.sum(axis=1, keepdims=True)
    K = tw.shape[0]
    top_ids = np.argsort(tw, axis=1)[:, ::-1][:, :top_n]
    ncols = 2
    nrows = int(math.ceil(K / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(12, 2.6 * nrows))
    axes = np.array(axes).reshape(-1)
    for k in range(K):
        ax = axes[k]
        ids = top_ids[k][::-1]
        ax.barh(range(len(ids)), tw[k, ids])
        ax.set_yticks(range(len(ids)))
        ax.set_yticklabels(vocab[ids], fontsize=9)
        ax.set_title(f"Topic {k}", fontsize=11)
        ax.invert_yaxis()
    for j in range(K, len(axes)):
        axes[j].axis("off")
    fig.suptitle(title, y=1.02, fontsize=14)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)

def plot_group_prevalence(theta, labels, order, outpath, title):
    K = theta.shape[1]
    dfp = pd.DataFrame(theta)
    dfp["group"] = labels
    mean = dfp.groupby("group").mean().reindex(order)
    x = np.arange(K)
    width = 0.35 if len(order) == 2 else 0.18
    fig = plt.figure(figsize=(12, 5))
    ax = fig.add_subplot(111)
    for i, g in enumerate(order):
        ax.bar(x + (i - (len(order) - 1) / 2) * width, mean.loc[g].values, width, label=g)
    ax.set_xticks(x)
    ax.set_xticklabels([f"T{k}" for k in range(K)])
    ax.set_ylabel("Average topic proportion")
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(outpath, dpi=300)
    plt.close(fig)

def topic_logodds(theta, doc_len, labels, A, B, prior=1.0):
    theta = np.asarray(theta)
    lens = np.asarray(doc_len).reshape(-1, 1)
    exp = theta * lens
    mA = (labels == A)
    mB = (labels == B)
    cA = exp[mA].sum(axis=0) + prior
    cB = exp[mB].sum(axis=0) + prior
    nA = cA.sum()
    nB = cB.sum()
    delta = np.log(cA / (nA - cA)) - np.log(cB / (nB - cB))
    var = 1 / cA + 1 / cB
    return delta / np.sqrt(var)

def plot_logodds(z, title, outpath):
    order = np.argsort(z)
    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111)
    ax.barh(range(len(z)), z[order])
    ax.set_yticks(range(len(z)))
    ax.set_yticklabels([f"T{i}" for i in order])
    ax.axvline(0, linewidth=1)
    ax.set_xlabel("log-odds z (positive => left group overrepresented)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300)
    plt.close(fig)

def plot_heatmap(mat, rows, cols, title, outpath):
    fig = plt.figure(figsize=(12, 4.5))
    ax = fig.add_subplot(111)
    im = ax.imshow(mat, aspect="auto")
    ax.set_yticks(np.arange(len(rows)))
    ax.set_yticklabels(rows)
    ax.set_xticks(np.arange(len(cols)))
    ax.set_xticklabels(cols)
    ax.set_title(title)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300)
    plt.close(fig)

def write_simple_html(csv_path, outpath, title):
    d = pd.read_csv(csv_path, encoding="utf-8-sig")
    with open(outpath, "w", encoding="utf-8") as f:
        f.write(f"<h2>{title}</h2>\n")
        f.write(d.to_html(index=False))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="조선시대 계회시 목록.xlsx")
    ap.add_argument("--outdir", default="lda_bigram_topic_results")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    set_cjk_font()

    df = pd.read_excel(args.data, sheet_name=0)
    df["styleN"] = df["문체"].apply(parse_styleN)
    df["bigrams"] = df.apply(lambda r: extract_bigrams(r["원문"], r["styleN"]), axis=1)
    df["n_bigrams"] = df["bigrams"].apply(len)
    df = df[df["n_bigrams"] >= 5].copy()

    df["is_private"] = df["유형"].astype(str).str.contains("0")
    df["office4"] = df["유형"].apply(office4_label)

    # ---------- A) 개인 vs 관청 ----------
    texts_all = [" ".join(t) for t in df["bigrams"]]
    bestK_A, score_A, _, vec_A, X_A, models_A = select_K(
        texts_all, K_GRID, min_df=3, max_df=0.7, outdir=args.outdir, max_iter=18, title_prefix="A_private_vs_official"
    )
    lda_A = models_A[bestK_A]
    vocab_A = np.array(vec_A.get_feature_names_out())
    theta_A = lda_A.transform(X_A)
    doc_len_A = df["bigrams"].apply(len).values
    grp_A = np.where(df["is_private"].values, "개인", "관청")

    plot_top_terms(lda_A, vocab_A, os.path.join(args.outdir, "A_topics_top_terms.png"),
                   f"A) 개인 vs 관청 토픽(2-gram), K={bestK_A}")
    plot_group_prevalence(theta_A, grp_A, ["개인", "관청"], os.path.join(args.outdir, "A_topic_prevalence_by_group.png"),
                          "A) 집단별 평균 토픽 비중")
    zA = topic_logodds(theta_A, doc_len_A, grp_A, "개인", "관청")
    plot_logodds(zA, "A) 토픽 과대표현 log-odds z (개인−관청)", os.path.join(args.outdir, "A_topic_logodds_private_minus_official.png"))

    score_A.to_csv(os.path.join(args.outdir, "A_k_selection_scores.csv"), index=False, encoding="utf-8-sig")
    topicA = topic_terms_df(lda_A, vocab_A)
    topicA.to_csv(os.path.join(args.outdir, "A_topic_terms_table.csv"), index=False, encoding="utf-8-sig")
    write_simple_html(os.path.join(args.outdir, "A_topic_terms_table.csv"), os.path.join(args.outdir, "A_topics_table.html"),
                      f"A) 개인 vs 관청 토픽 요약(K={bestK_A})")

    # ---------- B) 4개 관청 ----------
    df_off4 = df[df["office4"].notna()].copy()
    texts_off4 = [" ".join(t) for t in df_off4["bigrams"]]
    bestK_B, score_B, _, vec_B, X_B, models_B = select_K(
        texts_off4, K_GRID, min_df=2, max_df=0.75, outdir=args.outdir, max_iter=20, title_prefix="B_office4"
    )
    lda_B = models_B[bestK_B]
    vocab_B = np.array(vec_B.get_feature_names_out())
    theta_B = lda_B.transform(X_B)
    doc_len_B = df_off4["bigrams"].apply(len).values
    grp_B = df_off4["office4"].values

    plot_top_terms(lda_B, vocab_B, os.path.join(args.outdir, "B_topics_top_terms.png"),
                   f"B) 4개 관청 토픽(2-gram), K={bestK_B}")

    mean_by = pd.DataFrame(theta_B).assign(office=grp_B).groupby("office").mean().reindex(["사헌부", "사간원", "승정원", "의금부"])
    plot_heatmap(mean_by.values, mean_by.index.tolist(), [f"T{k}" for k in range(bestK_B)],
                 "B) 관청별 평균 토픽 비중", os.path.join(args.outdir, "B_topic_prevalence_heatmap_office4.png"))

    # office vs rest log-odds z heatmap
    theta = np.asarray(theta_B)
    lens = np.asarray(doc_len_B).reshape(-1, 1)
    exp = theta * lens
    offices = ["사헌부", "사간원", "승정원", "의금부"]
    Z = []
    for off in offices:
        m = (grp_B == off)
        c1 = exp[m].sum(axis=0) + 1.0
        c2 = exp[~m].sum(axis=0) + 1.0
        n1 = c1.sum(); n2 = c2.sum()
        delta = np.log(c1 / (n1 - c1)) - np.log(c2 / (n2 - c2))
        var = 1 / c1 + 1 / c2
        Z.append(delta / np.sqrt(var))
    plot_heatmap(np.vstack(Z), offices, [f"T{k}" for k in range(bestK_B)],
                 "B) 관청별 토픽 과대표현 log-odds z", os.path.join(args.outdir, "B_topic_logodds_heatmap_office_vs_rest.png"))

    score_B.to_csv(os.path.join(args.outdir, "B_k_selection_scores.csv"), index=False, encoding="utf-8-sig")
    topicB = topic_terms_df(lda_B, vocab_B)
    topicB.to_csv(os.path.join(args.outdir, "B_topic_terms_table.csv"), index=False, encoding="utf-8-sig")
    write_simple_html(os.path.join(args.outdir, "B_topic_terms_table.csv"), os.path.join(args.outdir, "B_topics_table.html"),
                      f"B) 4개 관청 토픽 요약(K={bestK_B})")

if __name__ == "__main__":
    main()
